# Realme XT Game Mode — Universal Android 8+

A no-root Android gaming utility targeting Android 8.0 (API 26) through current Android versions.

## Included
- One-tap foreground gaming session
- 60 FPS target profile (does not force protected game limits)
- Free Fire launch button
- Network transport monitoring
- Battery percentage monitoring
- Persistent gaming notification
- Safe stop button
- Java/Kotlin JVM 17 alignment for reliable cloud builds

## Compatibility
- Minimum Android: 8.0 / API 26
- Target Android: 15 / API 35
- Designed to run across Android 8 through current releases, subject to OEM restrictions.
- Android 13+ requires notification permission for the persistent gaming notification.
- Android 14+ requires the declared special-use foreground-service permission/type; the app starts it from a visible user action.

## Important limitations
This app does not modify Free Fire APK/OBB/data files, bypass anti-cheat, override Android thermal protection, or guarantee a 60 FPS lock. The 60 FPS setting is a target/profile. Network monitoring does not increase ISP bandwidth or magically lower ping.

## Cloud build
The included `.github/workflows/build-apk.yml` builds a debug APK using JDK 17 and Gradle 8.11.
