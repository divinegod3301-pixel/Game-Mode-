package com.realme.xtgamemode

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private lateinit var status: TextView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.rgb(11, 16, 32))
        }

        val title = TextView(this).apply {
            text = "🎮  XT GAME MODE"
            textSize = 24f
            setTextColor(Color.WHITE)
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "Universal • Android 8.0+ • 60 FPS target"
            setTextColor(Color.LTGRAY)
        }
        root.addView(sub)

        status = TextView(this).apply {
            text = "● GAME MODE OFF"
            textSize = 18f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, dp(20))
        }
        root.addView(status)

        val start = Button(this).apply { text = "START GAME MODE" }
        val stop = Button(this).apply { text = "STOP GAME MODE" }
        val launch = Button(this).apply { text = "OPEN FREE FIRE" }

        root.addView(start)
        root.addView(stop)
        root.addView(launch)

        val info = TextView(this).apply {
            text = "\n60 FPS target • network monitor • battery monitor • foreground gaming session\n\nWorks from Android 8.0 onward. It does not edit Free Fire files or bypass anti-cheat."
            setTextColor(Color.LTGRAY)
        }
        root.addView(info)

        start.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 44)
            }
            val i = Intent(this, GameModeService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            status.text = "● GAME MODE ACTIVE"
        }

        stop.setOnClickListener {
            stopService(Intent(this, GameModeService::class.java))
            status.text = "● GAME MODE OFF"
        }

        launch.setOnClickListener {
            val pm = packageManager
            val launchIntent = pm.getLaunchIntentForPackage("com.dts.freefireth")
                ?: pm.getLaunchIntentForPackage("com.dts.freefiremax")
            if (launchIntent != null) {
                startActivity(launchIntent)
            } else {
                Toast.makeText(this, "Free Fire not found", Toast.LENGTH_SHORT).show()
            }
        }

        setContentView(root)
    }
}
