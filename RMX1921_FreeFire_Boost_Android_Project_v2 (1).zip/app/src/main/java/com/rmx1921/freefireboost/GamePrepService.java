package com.rmx1921.freefireboost;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import java.util.*;

public class GamePrepService extends Service {
    private PowerManager.WakeLock lock;

    @Override public void onCreate() {
        super.onCreate();
        String channel = "gaming";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(channel, "Gaming session",
                    NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, channel)
                .setContentTitle("RMX1921 Gaming Prep")
                .setContentText("Gaming session active")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        startForeground(7, n);

        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        lock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"RMX1921Boost:Service");
        lock.acquire(6*60*60*1000L);
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        return START_NOT_STICKY;
    }

    @Override public void onDestroy(){
        if(lock!=null && lock.isHeld()) lock.release();
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent){ return null; }
}
