package com.rmx1921.freefireboost;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private PowerManager.WakeLock wakeLock;
    private TextView status;
    private static final String[] FREE_FIRE_PACKAGES = {
        "com.dts.freefireth",
        "com.dts.freefiremax"
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Android 7+ sustained-performance request. This is only honored when
        // the device/OEM supports it; it cannot disable thermal protection.
        if (Build.VERSION.SDK_INT >= 24) {
            PowerManager pm = (PowerManager)getSystemService(POWER_SERVICE);
            if (pm != null && pm.isSustainedPerformanceModeSupported()) {
                getWindow().setSustainedPerformanceMode(true);
            }
        }

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }

        findViewById(R.id.boostPlay).setOnClickListener(v -> boostAndPlay());
        findViewById(R.id.thermal).setOnClickListener(v -> showThermal());
        findViewById(R.id.settings).setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)));
    }

    private void boostAndPlay() {
        try {
            PowerManager pm = (PowerManager)getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RMX1921Boost:GamePrep");
                wakeLock.acquire(10 * 60 * 60 * 1000L);
            }

            Intent s = new Intent(this, GamePrepService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s);
            else startService(s);

            Intent launch = null;
            for (String pkg : FREE_FIRE_PACKAGES) {
                launch = getPackageManager().getLaunchIntentForPackage(pkg);
                if (launch != null) break;
            }
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                status.setText("BOOST PREPARED • Launching Free Fire…");
                startActivity(launch);
            } else {
                status.setText("Free Fire package not found. Open Free Fire normally, then return here.");
            }
        } catch (Exception e) {
            status.setText("Launch error: " + e.getMessage());
        }
    }

    private void showThermal() {
        if (Build.VERSION.SDK_INT >= 29) {
            PowerManager pm = (PowerManager)getSystemService(POWER_SERVICE);
            int t = pm.getCurrentThermalStatus();
            String x;
            switch (t) {
                case PowerManager.THERMAL_STATUS_NONE: x="NONE — normal"; break;
                case PowerManager.THERMAL_STATUS_LIGHT: x="LIGHT"; break;
                case PowerManager.THERMAL_STATUS_MODERATE: x="MODERATE"; break;
                case PowerManager.THERMAL_STATUS_SEVERE: x="SEVERE — performance may be reduced"; break;
                case PowerManager.THERMAL_STATUS_CRITICAL: x="CRITICAL — cool the phone"; break;
                default: x="Status "+t;
            }
            status.setText("THERMAL: " + x);
        } else status.setText("Thermal API unavailable on this Android version.");
    }

    @Override protected void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
}
