# RMX1921 Free Fire Boost & Play

Target: realme XT RMX1921, Android 11, realme UI 2.0, Snapdragon 712, 4 GB RAM.

This is a non-root Android companion app. It intentionally does not modify Free Fire files or claim impossible hardware overclocking.

Features:
- Requests Android sustained-performance mode when supported
- BOOST & PLAY launch
- Screen-awake handling
- Foreground gaming-session service
- Android thermal status display
- Battery optimization settings shortcut
- Immersive fullscreen preparation

Limitations:
- A normal Android 11 app cannot force 160 FPS in Free Fire.
- It cannot disable Android thermal throttling.
- It cannot set Snapdragon CPU/GPU clocks without privileged/root/OEM support.
- It cannot inject files into Free Fire safely.

Build:
Open this project in Android Studio or AndroidIDE and build/install the debug APK.
