package com.tyro.kanji

import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.time.LocalDate
import java.time.LocalTime
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.tyro.kanji.data.KanjiEntity
import kotlin.math.PI
import kotlin.math.sin

private val Sakura = Color(0xFFE56B88)
private val SakuraSoft = Color(0xFFFFB8C7)
private val Ink = Color(0xFF17151B)
private val Night = Color(0xFF111116)
private val NightCard = Color(0xFF1A1920)
private val Cream = Color(0xFFFFF7F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TyroKanjiApp() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if ((requestCode == 9002) &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        ) {
            NotificationScheduler.schedule(this)
        }
    }
}

@Composable
fun TyroKanjiApp(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val theme by vm.theme.collectAsState()
    val prefs = LocalContext.current.getSharedPreferences("tyro_settings", 0)
    var onboardingDone by remember { mutableStateOf(prefs.getBoolean("onboarding_done", false)) }
    val currentMinute = rememberCurrentMinute()
    val dynamicNight = theme == "japan_dynamic" && isJapanNight(currentMinute)
    val dark = theme == "dark" || theme == "fireworks" || dynamicNight || (theme == "system" && androidx.compose.foundation.isSystemInDarkTheme())

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = Sakura, secondary = SakuraSoft, background = Night, surface = NightCard)
        else lightColorScheme(primary = Sakura, secondary = Color(0xFF9E4960), background = Cream, surface = Color.White)
    ) {
        if (!onboardingDone) {
            ThemeOnboarding(dark, vm) {
                prefs.edit().putBoolean("onboarding_done", true).commit()
                onboardingDone = true
            }
        } else {
            Box(Modifier.fillMaxSize()) {
                LiveBackground(theme, Modifier.fillMaxSize())
                NavHost(navController = nav, startDestination = "home", modifier = Modifier.fillMaxSize()) {
                    composable("home") { Home(vm, dark, nav) }
                    composable("learn") { Learn(vm, nav) }
                    composable("study") { Study(vm, nav) }
                    composable("stats") { Stats(vm, nav) }
                    composable("settings") { Settings(nav, vm, dark) }
                    composable("settings/learning") { LearningContent(vm, nav) }
                    composable("settings/flashcards") { FlashcardSettings(vm, nav) }
                    composable("settings/quiz") { QuizSettings(nav) }
                    composable("settings/widget") { WidgetAppearance(vm, nav, dark) }
                    composable("settings/theme") { ThemeSettings(vm, nav, dark) }
                    composable("settings/jlpt") { JlptSettings(vm, nav) }
                    composable("settings/notifications") { NotificationSettings(nav) }
                    composable("settings/backup") { SimpleSettingsPage("Backup", "Your learning data is stored locally on the device. Backup/export can be added here without changing your study data.", nav) }
                    composable("settings/faq") { SimpleSettingsPage("FAQ", "Choose your Kanji in Learning content, refresh Study for a new Kanji, and use the widget ↻ button for an instant change.", nav) }
                    composable("detail/{id}") { entry ->
                        val id = entry.arguments?.getString("id")?.toIntOrNull()
                        val k by vm.kanji.collectAsState()
                        k.firstOrNull { it.id == id }?.let { Detail(it, vm, nav) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeOnboarding(initialDark: Boolean, vm: MainViewModel, onBegin: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        LiveBackground("japan_dynamic", Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))
            Text("TYRO KANJI", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Bold)
            Text("Learn Kanji. Live Japan.", color = Color.White.copy(.92f), fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(16.dp))
            Card(
                Modifier.fillMaxWidth().weight(1f),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF4F4E7).copy(.94f))
            ) {
                Column(
                    Modifier.fillMaxSize().padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Dynamic Japan", color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Your default theme — it changes naturally with time and season.",
                        color = Ink.copy(.68f), fontSize = 13.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    ThemeChoice("🌿 Japan • Time-Aware", "japan_dynamic", true) { }
                    Spacer(Modifier.height(12.dp))
                    InfoLine(Icons.Default.Schedule, "Sunrise → Day → Sunset → Night", "The landscape and UI lighting follow local time")
                    InfoLine(Icons.Default.FilterVintage, "Four seasons", "Spring, summer, autumn and winter subtly change the scene")
                    InfoLine(Icons.Default.Landscape, "Japanese vector landscape", "Mountains, torii, trees, temples and city silhouettes")
                    InfoLine(Icons.Default.AutoAwesome, "Always in the background", "The same visual system adapts across every app page")
                    Spacer(Modifier.weight(1f))
                    Button(
                        { vm.setTheme("japan_dynamic"); onBegin() },
                        Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("Start with Dynamic Japan  ✦") }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("A quiet Japan that changes with your day.", color = Color.White.copy(.9f), fontSize = 13.sp)
        }
    }
}

@Composable
private fun SakuraScene(dark: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "sakuraPetals")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(9000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        ),
        label = "petalDrift"
    )
    val top = if (dark) Color(0xFF17131F) else Color(0xFFFFEEF5)
    val middle = if (dark) Color(0xFF4A2538) else Color(0xFFFFD5C8)
    val bottom = if (dark) Color(0xFF9A4D50) else Color(0xFFFFB6A4)
    val sun = if (dark) Color(0xFFFFB45C) else Color(0xFFFFD78D)
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(listOf(top, middle, bottom)))
        // Soft sunset glow
        drawCircle(sun.copy(alpha = if (dark) .88f else .78f), size.minDimension * .115f, Offset(size.width * .70f, size.height * .57f))
        drawCircle(Color.White.copy(alpha = if (dark) .05f else .22f), size.minDimension * .19f, Offset(size.width * .70f, size.height * .57f))
        // Distant Fuji-like mountains and nearer hills
        mountain(this, Color(0xFF5C4A60).copy(alpha = if (dark) .90f else .36f), .52f, .38f)
        mountain(this, Color(0xFF332B3D).copy(alpha = if (dark) .94f else .30f), .78f, .48f)
        // Water and reflection
        drawRect(Color(0xFF342D42).copy(alpha = if (dark) .72f else .14f), Offset(0f, size.height*.70f), androidx.compose.ui.geometry.Size(size.width,size.height*.30f))
        for (i in 0 until 10) {
            val y = size.height * (.73f + i * .022f)
            val width = size.width * (.12f + (i % 4) * .05f)
            drawLine(Color(0xFFFFC4B2).copy(alpha = if (dark) .16f else .24f), Offset(size.width*.70f-width, y), Offset(size.width*.70f+width, y), strokeWidth = 2f)
        }
        // Pagoda silhouette
        val px = size.width * .84f; val base = size.height * .72f
        drawRect(Color(0xFF2A222F).copy(alpha=.90f), Offset(px-size.width*.014f, base-size.height*.30f), androidx.compose.ui.geometry.Size(size.width*.028f,size.height*.30f))
        repeat(4) { i ->
            val y = base - i * size.height * .055f
            val w = size.width * (.14f - i * .018f)
            drawRect(Color(0xFF2A222F).copy(alpha=.92f), Offset(px-w/2, y-size.height*.045f), androidx.compose.ui.geometry.Size(w, size.height*.045f))
            val roof = Path().apply { moveTo(px-w*.72f,y-size.height*.045f); lineTo(px,y-size.height*.073f); lineTo(px+w*.72f,y-size.height*.045f); close() }
            drawPath(roof, Color(0xFF1E1924).copy(alpha=.96f))
        }
        // Torii silhouette
        val tx = size.width * .24f; val ty = size.height * .72f
        val torii = Color(0xFF8F3D4C).copy(alpha = if (dark) .85f else .58f)
        drawRect(torii, Offset(tx-size.width*.045f, ty-size.height*.17f), androidx.compose.ui.geometry.Size(size.width*.018f,size.height*.18f))
        drawRect(torii, Offset(tx+size.width*.027f, ty-size.height*.17f), androidx.compose.ui.geometry.Size(size.width*.018f,size.height*.18f))
        drawRect(torii, Offset(tx-size.width*.075f, ty-size.height*.18f), androidx.compose.ui.geometry.Size(size.width*.15f,size.height*.024f))
        // Sakura branch silhouette in the upper-left corner
        val branch = Color(0xFF2A2027).copy(alpha = if (dark) .85f else .55f)
        drawLine(branch, Offset(0f, size.height*.13f), Offset(size.width*.36f, size.height*.02f), strokeWidth = size.minDimension*.025f)
        drawLine(branch, Offset(size.width*.18f, size.height*.08f), Offset(size.width*.30f, size.height*.25f), strokeWidth = size.minDimension*.012f)
        // Gently falling petals
        for (i in 0 until 32) {
            val seedX = ((i * 37) % 101) / 100f
            val seedY = ((i * 61) % 101) / 100f
            val x = (seedX + sin((drift * 2f + i) * 1.7f) * .035f).coerceIn(.02f,.98f) * size.width
            val y = ((seedY + drift * (.32f + (i % 4) * .08f)) % 1f) * size.height
            val r = 2.5f + (i % 3)
            drawCircle(SakuraSoft.copy(alpha = if (dark) .88f else .72f), r, Offset(x,y))
            if (i % 5 == 0) drawCircle(Color.White.copy(alpha=.16f), r*.55f, Offset(x-r*.25f,y-r*.25f))
        }
        // foreground vignette
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = if (dark) .16f else .05f))), Offset.Zero, size)
    }
}

private fun mountain(scope: DrawScope, color: Color, x: Float, peak: Float) {
    val p = Path().apply { moveTo(0f, scope.size.height*.72f); lineTo(scope.size.width*x, scope.size.height*peak); lineTo(scope.size.width, scope.size.height*.72f); close() }
    scope.drawPath(p, color)
}


@Composable
private fun LiveBackground(theme: String, modifier: Modifier = Modifier) {
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    val minute by rememberCurrentMinuteState()
    val actual = when (theme) {
        "system" -> if (systemDark) "dark" else "light"
        else -> theme
    }
    val motion = rememberInfiniteTransition(label = "liveTheme")
    val drift by motion.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Restart),
        label = "themeMotion"
    )

    Canvas(modifier) {
        if (actual == "japan_dynamic") {
            drawDynamicJapan(this, minute, drift)
            return@Canvas
        }

        when (actual) {
            "winter" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF9ED7F0), Color(0xFFEAF7FF), Color(0xFFD9EEF4))))
                val peak = Offset(size.width*.50f, size.height*.23f)
                val baseY = size.height*.62f
                val mountain = Path().apply { moveTo(size.width*.05f,baseY); lineTo(peak.x,peak.y); lineTo(size.width*.95f,baseY); close() }
                drawPath(mountain, Color(0xFF7188A0).copy(.78f))
                val snow = Path().apply { moveTo(size.width*.35f,size.height*.43f); lineTo(peak.x,peak.y); lineTo(size.width*.65f,size.height*.43f); lineTo(size.width*.56f,size.height*.36f); lineTo(size.width*.50f,size.height*.28f); lineTo(size.width*.44f,size.height*.37f); close() }
                drawPath(snow, Color.White.copy(.94f))
                drawRect(Color(0xFF7FA8B8).copy(.45f), Offset(0f,size.height*.61f), androidx.compose.ui.geometry.Size(size.width,size.height*.39f))
                for(i in 0 until 70){
                    val x=((i*83)%100)/100f*size.width
                    val y=(((i*47)%100)/100f + drift*((i%5+1)*.16f))%1f*size.height
                    drawCircle(Color.White.copy(.82f), 1.5f+(i%3), Offset(x,y))
                }
            }
            "fireworks" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF080B25), Color(0xFF17143A), Color(0xFF2B2045))))
                drawCircle(Color(0xFFFAE3A5).copy(.8f), size.minDimension*.055f, Offset(size.width*.78f,size.height*.20f))
                drawRect(Color(0xFF172A46).copy(.86f), Offset(0f,size.height*.72f), androidx.compose.ui.geometry.Size(size.width,size.height*.28f))
                val c=Offset(size.width*.72f,size.height*.62f); val r=size.minDimension*.13f
                drawCircle(Color(0xFFFF9A62).copy(.75f),r,c,style=androidx.compose.ui.graphics.drawscope.Stroke(4f))
                for(i in 0 until 8){ val a=i*3.14159265f/4f; drawLine(Color(0xFFFFC56E).copy(.65f),c,Offset(c.x+sin(a)*r,c.y+(-kotlin.math.cos(a))*r),2f)}
                for(i in 0 until 8){
                    val phase=((drift + i*.13f)%1f)
                    if(phase>.35f){
                        val cx=((i*31)%90)/100f*size.width+size.width*.05f
                        val cy=size.height*(.16f+((i*17)%34)/100f)
                        val rr=size.minDimension*.10f*(phase-.35f)/.65f
                        for(j in 0 until 12){
                            val a=j*3.14159265f/6f
                            val end=Offset(cx+sin(a)*rr,cy+(-kotlin.math.cos(a))*rr)
                            drawLine(Color(0xFFFFD166).copy(alpha=(1f-phase)),Offset(cx,cy),end,2.5f)
                        }
                    }
                }
            }
            "dark" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF080A19), Color(0xFF19172D), Color(0xFF27203A))))
                for(i in 0 until 48){
                    val x=((i*47)%100)/100f*size.width
                    val y=((i*71)%100)/100f*size.height
                    val blink=(sin(drift*3.14159265f*2f+i)*.5f+.5f)
                    drawCircle(Color(0xFFFFD98A).copy(alpha=.25f+.65f*blink), 1.5f+(i%3), Offset(x,y))
                }
            }
            else -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFFFFEAF3), Color(0xFFFFF6EE), Color(0xFFFFD7CC))))
                for(i in 0 until 55){
                    val x=((i*37)%100)/100f*size.width
                    val y=(((i*61)%100)/100f + drift*((i%4+.7f)*.22f))%1f*size.height
                    drawCircle(Color(0xFFE889A4).copy(.62f),2f+(i%3),Offset(x,y))
                }
            }
        }
    }
}

private fun rememberCurrentMinuteState(): State<Long> {
    val state = remember { mutableLongStateOf(currentMinuteOfDay()) }
    LaunchedEffect(Unit) {
        while (true) {
            state.longValue = currentMinuteOfDay()
            delay(60_000L)
        }
    }
    return state
}

@Composable
private fun rememberCurrentMinute(): Long = rememberCurrentMinuteState().value

private fun currentMinuteOfDay(): Long {
    val now = LocalTime.now()
    return now.hour * 60L + now.minute
}

private fun isJapanNight(minute: Long): Boolean = minute < 5 * 60L || minute >= 20 * 60L

private fun lerpColor(a: Color, b: Color, t: Float): Color {
    val x = t.coerceIn(0f, 1f)
    return Color(
        red = a.red + (b.red - a.red) * x,
        green = a.green + (b.green - a.green) * x,
        blue = a.blue + (b.blue - a.blue) * x,
        alpha = a.alpha + (b.alpha - a.alpha) * x
    )
}

private fun timePalette(minute: Long): List<Color> {
    // Dawn → green day → golden sunset → indigo night → dawn.
    val keyframes = listOf(
        0L to listOf(Color(0xFF071B2A), Color(0xFF123D49), Color(0xFF246A62)),
        5 * 60L to listOf(Color(0xFFFFDCA8), Color(0xFF9CC8A0), Color(0xFF4C9A83)),
        8 * 60L to listOf(Color(0xFFE9F2D2), Color(0xFFAED3A6), Color(0xFF2C9C79)),
        16 * 60L to listOf(Color(0xFFEAF1D2), Color(0xFF9DCB9C), Color(0xFF239A78)),
        18 * 60L to listOf(Color(0xFFFFD39A), Color(0xFFEFA66F), Color(0xFF7A6A83)),
        20 * 60L to listOf(Color(0xFF071B2A), Color(0xFF123D49), Color(0xFF173C58))
    )
    val m = minute % (24 * 60L)
    val prev = keyframes.lastOrNull { it.first <= m } ?: keyframes.last()
    val next = keyframes.firstOrNull { it.first > m } ?: keyframes.first()
    val endMinute = if (next.first > prev.first) next.first else next.first + 24*60L
    val current = if (m < prev.first) m + 24*60L else m
    val t = ((current - prev.first).toFloat() / (endMinute - prev.first).toFloat()).coerceIn(0f,1f)
    return prev.second.indices.map { i -> lerpColor(prev.second[i], next.second[i], t) }
}

private fun drawDynamicJapan(scope: DrawScope, minute: Long, drift: Float) {
    with(scope) {
        val palette = timePalette(minute)
        drawRect(Brush.verticalGradient(palette))
        val m = minute % (24 * 60L)
        val daylight = m in (5*60L)..(20*60L)
        val sunset = m in (17*60L)..(20*60L)
        val sunrise = m in (5*60L)..(8*60L)
        val season = when (LocalDate.now().monthValue) {
            3,4,5 -> "spring"
            6,7,8 -> "summer"
            9,10,11 -> "autumn"
            else -> "winter"
        }

        // Sun/moon follows the real local time.
        val celestial = if (daylight) {
            val dayProgress = ((m - 5*60L).toFloat() / (15*60L)).coerceIn(0f,1f)
            Offset(size.width*(.10f + .78f*dayProgress), size.height*(.42f - .25f*sin(dayProgress*PI).toFloat()))
        } else {
            val nightStart = if (m >= 20*60L) m-20*60L else m+4*60L
            val nightProgress = (nightStart.toFloat()/(9*60L)).coerceIn(0f,1f)
            Offset(size.width*(.18f + .64f*nightProgress), size.height*.20f)
        }
        val celestialColor = if (daylight) Color(0xFFFFF1B8) else Color(0xFFF7E8B0)
        drawCircle(celestialColor.copy(alpha=.88f), size.minDimension*.045f, celestial)
        drawCircle(celestialColor.copy(alpha=.12f), size.minDimension*.10f, celestial)

        // Layered green mountains: the signature default look.
        drawLayeredHills(this, Color(0xFFBCD7B2), Color(0xFF7FB59B), Color(0xFF3B9A7B), Color(0xFF167C68))
        // A distant Fuji-like peak.
        val fx=size.width*.67f
        val fy=size.height*.39f
        val fb=size.height*.64f
        val fuji=Path().apply{moveTo(fx-size.width*.20f,fb);lineTo(fx,fy);lineTo(fx+size.width*.20f,fb);close()}
        drawPath(fuji, Color(0xFF5C9B89).copy(.58f))
        val snow=Path().apply{moveTo(fx-size.width*.08f,fy+size.height*.11f);lineTo(fx,fy);lineTo(fx+size.width*.10f,fy+size.height*.11f);lineTo(fx+size.width*.045f,fy+size.height*.08f);lineTo(fx,fy+size.height*.055f);lineTo(fx-size.width*.035f,fy+size.height*.085f);close()}
        drawPath(snow, Color(0xFFF5F0D9).copy(alpha=if (daylight) 0.8f else 0.42f))

        // Season layer.
        when(season){
            "spring" -> for(i in 0 until 24){ val x=((i*43)%100)/100f*size.width; val y=(((i*29)%55)/100f+drift*.08f)%1f*size.height; drawCircle(Color(0xFFF4B7BE).copy(.58f),2.2f,Offset(x,y)) }
            "autumn" -> for(i in 0 until 20){ val x=((i*57)%100)/100f*size.width; val y=(((i*31)%60)/100f+drift*.10f)%1f*size.height; drawCircle(Color(0xFFD88955).copy(.64f),2.4f,Offset(x,y)) }
            "winter" -> for(i in 0 until 32){ val x=((i*41)%100)/100f*size.width; val y=(((i*67)%75)/100f+drift*.12f)%1f*size.height; drawCircle(Color.White.copy(.55f),1.8f,Offset(x,y)) }
            else -> { /* summer stays lush and clean */ }
        }

        // Distant city/temple silhouettes.
        val skyline = Color(0xFF082C2E).copy(alpha=if (daylight) 0.88f else 0.94f)
        for(i in 0 until 13){
            val x=size.width*(i/13f)
            val w=size.width*(.035f+(i%3)*.012f)
            val h=size.height*(.06f+(i%4)*.035f)
            drawRect(skyline,Offset(x,size.height*.72f-h),androidx.compose.ui.geometry.Size(w,h))
        }
        // Pagoda.
        val px=size.width*.82f; val base=size.height*.75f
        drawRect(skyline,Offset(px-size.width*.012f,base-size.height*.25f),androidx.compose.ui.geometry.Size(size.width*.024f,size.height*.25f))
        repeat(4){i->
            val y=base-i*size.height*.052f; val w=size.width*(.12f-i*.014f)
            drawRect(skyline,Offset(px-w/2,y-size.height*.035f),androidx.compose.ui.geometry.Size(w,size.height*.035f))
            val roof=Path().apply{moveTo(px-w*.72f,y-size.height*.035f);lineTo(px,y-size.height*.062f);lineTo(px+w*.72f,y-size.height*.035f);close()}
            drawPath(roof,skyline)
        }
        // Torii foreground.
        val tx=size.width*.28f; val ty=size.height*.76f
        drawRect(skyline,Offset(tx-size.width*.048f,ty-size.height*.19f),androidx.compose.ui.geometry.Size(size.width*.018f,size.height*.20f))
        drawRect(skyline,Offset(tx+size.width*.030f,ty-size.height*.19f),androidx.compose.ui.geometry.Size(size.width*.018f,size.height*.20f))
        drawRect(skyline,Offset(tx-size.width*.082f,ty-size.height*.21f),androidx.compose.ui.geometry.Size(size.width*.164f,size.height*.025f))
        drawRect(skyline,Offset(tx-size.width*.055f,ty-size.height*.155f),androidx.compose.ui.geometry.Size(size.width*.11f,size.height*.018f))

        // Night city lights / evening lantern glow.
        if(!daylight || sunset){
            for(i in 0 until 12){
                val x=size.width*(.05f+((i*71)%88)/100f)
                val y=size.height*(.67f+((i*19)%12)/100f)
                drawCircle(Color(0xFFFFD58A).copy(alpha=if (!daylight) 0.7f else 0.32f),2.2f,Offset(x,y))
            }
        }

        // Very subtle moving cloud bands.
        for(i in 0 until 4){
            val cx=((drift*(.10f+i*.025f)+i*.27f)%1.2f)-.1f
            val cy=size.height*(.12f+i*.075f)
            drawOval(Color.White.copy(alpha=if (daylight) 0.13f else 0.07f),Offset(size.width*cx,cy),androidx.compose.ui.geometry.Size(size.width*.16f,size.height*.035f))
        }

        // Foreground keeps the content readable while preserving the landscape.
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF06282C).copy(alpha=.42f))),
            Offset.Zero, size
        )
    }
}

private fun drawLayeredHills(scope: DrawScope, back: Color, mid: Color, near: Color, front: Color) {
    with(scope) {
        fun hill(y: Float, peak: Float, color: Color, offset: Float) {
            val p=Path().apply{
                moveTo(0f,size.height*y)
                var x=0f
                while(x<=size.width){
                    val n=sin((x/size.width*PI*2.0+offset).toFloat()).toDouble()
                    val yy=size.height*(y-peak*n.toFloat()*.12f)
                    lineTo(x,yy)
                    x+=size.width/10f
                }
                lineTo(size.width,size.height)
                lineTo(0f,size.height)
                close()
            }
            drawPath(p,color)
        }
        hill(.48f,.40f,back,.2f)
        hill(.58f,.34f,mid,1.3f)
        hill(.68f,.28f,near,2.0f)
        hill(.78f,.22f,front,.7f)
    }
}

@Composable
private fun ThemeCardScene(theme: String, modifier: Modifier = Modifier) {
    // Cards use the same live animated visual language as the currently selected theme.
    LiveBackground(theme, modifier)
}

private fun themeTextColor(theme: String): Color =
    if (theme == "dark" || theme == "fireworks" || (theme == "japan_dynamic" && isJapanNight(currentMinuteOfDay()))) Color.White else Ink


@Composable
private fun AppShell(title: String, nav: NavHostController, selected: Int, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (title != "Home") IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Back") }
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                if (title == "Home") IconButton({ nav.navigate("settings") }) { Icon(Icons.Default.Settings, "Settings") }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .96f)) {
                val items = listOf("Home" to Icons.Default.Home, "Learn" to Icons.Default.MenuBook, "Review" to Icons.Default.Replay, "Settings" to Icons.Default.Settings)
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = selected == i, onClick = {
                        val route = listOf("home", "learn", "study", "settings")[i]
                        nav.navigate(route) { launchSingleTop = true; popUpTo("home") }
                    }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 10.sp) })
                }
            }
        }
    ) { pad -> Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp), content = content) }
}

@Composable
private fun Home(vm: MainViewModel, dark: Boolean, nav: NavHostController) {
    val list by vm.kanji.collectAsState(); val mastered by vm.mastered.collectAsState(); val due by vm.due.collectAsState()
    val progress = if (list.isEmpty()) 0f else (mastered.toFloat() / list.size).coerceIn(0f, 1f)
    AppShell("TYRO KANJI", nav, 0) {
        Spacer(Modifier.height(2.dp))
        HeroCard(vm.theme.collectAsState().value)
        Spacer(Modifier.height(14.dp))
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(13.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(progress)
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("Progress", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Keep going. Every Kanji makes you stronger.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Correct  $mastered", fontWeight = FontWeight.SemiBold)
                        Text("Review   $due", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        val cards = listOf(
            Triple("Kanji", "${list.size} selected", Icons.Default.MenuBook),
            Triple("Quiz", "Test your knowledge", Icons.Default.School),
            Triple("Flash Cards", "Review & Remember", Icons.Default.Style),
            Triple("Review", "Mistakes & Mastery", Icons.Default.Replay),
            Triple("Kanji Details", "Meaning & Words", Icons.Default.Description),
            Triple("Widget", "Home screen study", Icons.Default.Widgets)
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            items(cards.chunked(2)) { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (title, sub, icon) ->
                        ActionCard(title, sub, icon, Modifier.weight(1f), onClick = {
                            when (title) { "Quiz", "Review", "Flash Cards" -> nav.navigate("study"); "Widget" -> nav.navigate("settings/widget"); "Kanji Details" -> list.firstOrNull()?.let { nav.navigate("detail/${it.id}") }; else -> nav.navigate("learn") }
                        })
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }

        }
    }
}

@Composable
private fun HeroCard(theme: String) {
    Box(Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(24.dp))) {
        LiveBackground(theme, Modifier.fillMaxSize())
        Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
            Text("TYRO KANJI", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
            Text("Learn Kanji. Live Japan.", color = Color.White.copy(.9f), fontSize = 14.sp)
        }
    }
}

@Composable
private fun ProgressRing(progress: Float) {
    Box(Modifier.size(82.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxSize(), strokeWidth = 8.dp, trackColor = MaterialTheme.colorScheme.surfaceVariant)
        Text("${(progress * 100).toInt()}%", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(13.dp).heightIn(min = 78.dp)) {
            Icon(icon, null, tint = Sakura, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(7.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
private fun FeatureStrip(dark: Boolean) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Widget" to Icons.Default.Widgets, "Offline" to Icons.Default.CloudOff, "Backup" to Icons.Default.CloudUpload, "Dark / Light" to Icons.Default.Brightness6).forEach { (label, icon) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Icon(icon, null, tint = Sakura, modifier = Modifier.size(22.dp)); Spacer(Modifier.height(4.dp)); Text(label, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun Learn(vm: MainViewModel, nav: NavHostController) {
    val list by vm.kanji.collectAsState(); var search by remember { mutableStateOf("") }
    val visible = list.filter { search.isBlank() || it.kanji.contains(search) || it.hiragana.contains(search, true) || it.meaning.contains(search, true) }
    AppShell("Learn", nav, 1) {
        OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search Kanji") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        Spacer(Modifier.height(10.dp))
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(visible, key = { it.id }) { k -> KanjiRow(k, vm) { nav.navigate("detail/${k.id}") } }
        }
    }
}

@Composable
private fun KanjiRow(k: KanjiEntity, vm: MainViewModel, onClick: () -> Unit) {
    val mastered by vm.isMastered(k.id).collectAsState(initial = false)
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Text(k.kanji, fontSize = 30.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(k.hiragana, fontWeight = FontWeight.SemiBold); Text(k.meaning, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) }
            IconButton(onClick = { vm.setMastered(k.id, !mastered) }) {
                Text(if (mastered) "👑" else "○", fontSize = 22.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Sakura)
        }
    }
}

@Composable
private fun Detail(k: KanjiEntity, vm: MainViewModel, nav: NavHostController) {
    val progress by vm.progress(k.id).collectAsState(initial = null)
    val theme by vm.theme.collectAsState()
    val textColor = themeTextColor(theme)
    var srsMessage by remember { mutableStateOf("") }
    val context = LocalContext.current
    lateinit var detailTts: TextToSpeech
    detailTts = remember { TextToSpeech(context) { status ->
        if (status == TextToSpeech.SUCCESS) detailTts.language = Locale.JAPANESE
    } }
    DisposableEffect(Unit) { onDispose { detailTts.stop(); detailTts.shutdown() } }
    val examples = remember(k.example) { k.example.split("|").filter { it.isNotBlank() } }
    val exampleReadings = remember(k.exampleRomaji) { k.exampleRomaji.split("|").filter { it.isNotBlank() } }
    val exampleMeanings = remember(k.exampleMeaning) { k.exampleMeaning.split("|").filter { it.isNotBlank() } }

    AppShell("Kanji Details", nav, 1) {
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth().height(205.dp), shape = RoundedCornerShape(28.dp)) {
            Box(Modifier.fillMaxSize()) {
                ThemeCardScene(theme, Modifier.fillMaxSize())
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(k.kanji, fontSize = 76.sp, fontWeight = FontWeight.Bold, color = textColor)
                    Text(k.meaning, fontSize = 18.sp, color = textColor)
                    Text("${k.hiragana}  •  ${k.romaji}", color = textColor.copy(alpha = .88f))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(13.dp)) {
                Text("Common use", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Meaning: ${k.meaning}")
                Text("Reading: ${k.hiragana}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Button({
                    val text = if (k.hiragana.isNotBlank() && k.hiragana != "—") k.hiragana else k.kanji
                    detailTts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kanji_${k.id}")
                }) {
                    Icon(Icons.Default.VolumeUp, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Play sound")
                }
                Spacer(Modifier.height(8.dp))
                Text("Mastery ${progress?.mastery ?: 0}/5", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Button({ vm.setMastered(k.id, (progress?.mastery ?: 0) < 5) }) {
                    Text(if ((progress?.mastery ?: 0) >= 5) "👑 Mastered — tap to unmark" else "👑 Mark as mastered")
                }
                Spacer(Modifier.height(8.dp))
                Button({ vm.favorite(k.id, !(progress?.favorite ?: false)) }) {
                    Icon(Icons.Default.Favorite, null); Spacer(Modifier.width(6.dp)); Text(if (progress?.favorite == true) "Saved" else "Favorite")
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
            Card(Modifier.weight(1f), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Readings", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("On'yomi", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(if (k.onyomi.isBlank()) "—" else k.onyomi, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Kun'yomi", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(if (k.kunyomi.isBlank()) "—" else k.kunyomi, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
            }
            Card(Modifier.weight(1f), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Common uses", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (examples.isEmpty()) {
                        Text("No common-use words available yet.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    } else {
                        examples.take(2).forEachIndexed { i, word ->
                            Text(word, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            if (i < exampleReadings.size) Text(exampleReadings[i], color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                            if (i < exampleMeanings.size) Text(exampleMeanings[i], color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                            if (i < minOf(2, examples.size) - 1) Spacer(Modifier.height(9.dp))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp)); Text("SRS review", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Again" to 0, "Hard" to 1, "Good" to 2, "Easy" to 3).forEach { (t, r) ->
                Button({ vm.review(k.id, r); srsMessage = "Saved: $t • next review updated" }, Modifier.weight(1f)) { Text(t, fontSize = 12.sp) }
            }
        }
        if (srsMessage.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(srsMessage, color = Sakura, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun Study(vm: MainViewModel, nav: NavHostController) {
    val all by vm.kanji.collectAsState(); val selected by vm.selectedIds.collectAsState(); val shuffle by vm.shuffle.collectAsState(); val token by vm.refreshToken.collectAsState()
    val theme by vm.theme.collectAsState()
    val list = remember(all, selected, shuffle, token) { vm.studyOrder(all) }
    var index by remember { mutableIntStateOf(0) }; var mode by remember { mutableIntStateOf(0) }; var reveal by remember { mutableStateOf(false) }
    var quizWrong by remember { mutableStateOf(false) }
    LaunchedEffect(list.size) { if (list.isNotEmpty()) index %= list.size }
    val k = list.getOrNull(index)
    fun nextStudy() {
        if (list.isNotEmpty()) index = (index + 1) % list.size
        reveal = false
        quizWrong = false
    }
    AppShell("Review", nav, 2) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(mode == 0, { mode = 0; quizWrong = false }, label = { Text("Flash Cards") }); Spacer(Modifier.width(8.dp)); FilterChip(mode == 1, { mode = 1; quizWrong = false }, label = { Text("Quiz") }); Spacer(Modifier.width(8.dp)); FilterChip(mode == 2, { mode = 2; quizWrong = false }, label = { Text("Mystery Cards") }); Spacer(Modifier.weight(1f)); Text("${if (list.isEmpty()) 0 else index + 1} / ${list.size}", color = MaterialTheme.colorScheme.onSurfaceVariant); IconButton({ vm.refreshStudy(); index = 0; reveal = false; quizWrong = false }) { Icon(Icons.Default.Refresh, "New Kanji") }
        }
        Spacer(Modifier.height(12.dp))
        if (k == null) EmptyStudy() else if (mode == 0) FlashCard(k, reveal, theme) { reveal = !reveal } else if (mode == 1) QuizCard(
            k, all,
            onCorrect = { vm.review(k.id, 2); nextStudy() },
            onWrong = { vm.review(k.id, 0); quizWrong = true }
        ) else MysteryCard(k, reveal, theme) { reveal = !reveal }
        Spacer(Modifier.height(12.dp))
        if (list.isNotEmpty() && (mode == 0 || mode == 2 || quizWrong)) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (mode == 0) OutlinedButton({ index = (index - 1 + list.size) % list.size; reveal = false }, Modifier.weight(1f)) { Text("Previous") }
            Button({ nextStudy() }, Modifier.weight(1f)) { Text("Next  →") }
        }
    }
}

@Composable
private fun EmptyStudy() { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(24.dp)) { Text("No Kanji selected", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("Open Settings → Learning content and choose the Kanji you want to learn.", color = MaterialTheme.colorScheme.onSurfaceVariant) } } }

@Composable
private fun FlashCard(k: KanjiEntity, reveal: Boolean, theme: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().height(360.dp).clickable(onClick = onClick), shape = RoundedCornerShape(28.dp)) {
        Box(Modifier.fillMaxSize()) {
            ThemeCardScene(theme, Modifier.fillMaxSize())
            val tc = themeTextColor(theme)
            Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Tap to ${if (reveal) "hide" else "reveal"}", color = tc.copy(alpha = .82f), fontSize = 12.sp)
                Spacer(Modifier.height(12.dp)); Text(k.kanji, fontSize = 78.sp, fontWeight = FontWeight.Bold, color = tc)
                if (reveal) { Text(k.meaning, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = tc); Text(k.hiragana, color = tc.copy(.9f)); Text(k.romaji, color = tc.copy(.72f)) }
            }
        }
    }
}

@Composable
private fun MysteryCard(k: KanjiEntity, reveal: Boolean, theme: String, onClick: () -> Unit) {
    val rotation by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (reveal) 180f else 0f,
        animationSpec = tween(420), label = "mysteryFlip"
    )
    val front = rotation <= 90f
    Card(
        Modifier.fillMaxWidth().height(360.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(28.dp)
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val tc = themeTextColor(theme)
            ThemeCardScene(theme, Modifier.fillMaxSize())
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                if (front) {
                    Text("?", color = tc, fontSize = 78.sp, fontWeight = FontWeight.Bold)
                    Text("Tap the card to reveal", color = tc.copy(.9f))
                    Text("Random Kanji", color = tc.copy(.7f), fontSize = 12.sp)
                } else {
                    Text(k.kanji, color = tc, fontSize = 78.sp, fontWeight = FontWeight.Bold)
                    Text(k.hiragana, color = tc, fontSize = 18.sp)
                    Text(k.meaning, color = tc, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    if (k.romaji.isNotBlank()) Text(k.romaji, color = tc.copy(.75f))
                }
            }
        }
    }
}

@Composable
private fun QuizCard(k: KanjiEntity, all: List<KanjiEntity>, onCorrect: () -> Unit, onWrong: () -> Unit) {
    var answered by remember(k.id) { mutableStateOf(false) }
    var selectedId by remember(k.id) { mutableIntStateOf(-1) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    lateinit var quizTts: TextToSpeech
    quizTts = remember(k.id) { TextToSpeech(context) { status ->
        if (status == TextToSpeech.SUCCESS) quizTts.language = Locale.JAPANESE
    } }
    DisposableEffect(k.id) { onDispose { quizTts.stop(); quizTts.shutdown() } }
    val opts = remember(k.id, all) { (listOf(k) + all.filter { it.id != k.id }.shuffled().take(3)).shuffled() }
    val isCorrect = selectedId == k.id
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("What is the meaning of this Kanji?", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(k.kanji, fontSize = 84.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(10.dp))
            IconButton({
                val text = if (k.hiragana.isNotBlank() && k.hiragana != "—") k.hiragana else k.kanji
                quizTts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "quiz_${k.id}")
            }, Modifier.align(Alignment.CenterHorizontally)) { Icon(Icons.Default.VolumeUp, "Play pronunciation") }
            Spacer(Modifier.height(4.dp))
            opts.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { o ->
                        val selected = selectedId == o.id
                        val correctShownAfterWrong = answered && !isCorrect && o.id == k.id
                        val stroke = when {
                            selected && answered && o.id == k.id -> Color(0xFF43A047)
                            selected && answered && o.id != k.id -> Color(0xFFE53935)
                            correctShownAfterWrong -> Color(0xFF43A047)
                            else -> MaterialTheme.colorScheme.outline
                        }
                        val fill = when {
                            selected && answered && o.id == k.id -> Color(0xFF43A047).copy(alpha = .25f)
                            selected && answered && o.id != k.id -> Color(0xFFE53935).copy(alpha = .25f)
                            correctShownAfterWrong -> Color(0xFF43A047).copy(alpha = .10f)
                            else -> Color.Transparent
                        }
                        Box(
                            Modifier.weight(1f).height(58.dp)
                                .border(1.5.dp, stroke, RoundedCornerShape(14.dp))
                                .background(fill, RoundedCornerShape(14.dp))
                                .clickable(enabled = !answered) {
                                    selectedId = o.id
                                    answered = true
                                    if (o.id == k.id) {
                                        scope.launch { delay(350); onCorrect() }
                                    } else {
                                        onWrong()
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(o.meaning, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
            }
            if (answered) {
                Text(if (isCorrect) "Correct! 🎉" else "Wrong!  Correct answer is highlighted in green.", color = if (isCorrect) Color(0xFF43A047) else Color(0xFFE53935), fontWeight = FontWeight.Bold)
                if (isCorrect) Text("Moving to next…", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                else Text("Tap Next to continue.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Stats(vm: MainViewModel, nav: NavHostController) {
    val total by vm.kanji.collectAsState(); val mastered by vm.mastered.collectAsState(); val due by vm.due.collectAsState(); val p = if (total.isEmpty()) 0f else mastered.toFloat()/total.size
    AppShell("Statistics", nav, 3) {
        Spacer(Modifier.height(8.dp)); Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(20.dp)) { Text("Your progress", fontSize = 24.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(16.dp)); ProgressRing(p); Spacer(Modifier.height(12.dp)); Text("$mastered mastered", fontWeight = FontWeight.Bold); Text("$due reviews due", color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(12.dp)); LinearProgressIndicator({ p }, Modifier.fillMaxWidth()) } }
        Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatTile("Total", total.size.toString(), Modifier.weight(1f)); StatTile("Mastered", mastered.toString(), Modifier.weight(1f)); StatTile("Due", due.toString(), Modifier.weight(1f)) }
    }
}

@Composable private fun StatTile(a: String, b: String, modifier: Modifier) { Card(modifier, shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(12.dp)) { Text(b, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text(a, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) } } }

@Composable
private fun Settings(nav: NavHostController, vm: MainViewModel, dark: Boolean) {
    AppShell("Settings", nav, 3) {
        Spacer(Modifier.height(4.dp)); Text("Personalize your Japanese study", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        SettingGroup("Learning", listOf("Learning content" to "Choose exactly which Kanji you learn", "Flashcards" to "Shuffle and study order", "Quiz" to "Question style", "JLPT level" to "JLPT availability"), nav)
        SettingGroup("Appearance", listOf("Widget appearance" to "Font, size, color & instant refresh", "Theme" to "Dark / Light themes"), nav)
        SettingGroup("Other", listOf("Notifications" to "Reminder controls", "Backup" to "Protect your progress", "FAQ" to "Help and tips"), nav)
        Spacer(Modifier.height(12.dp)); ThemePreviewRow(dark)
    }
}

@Composable
private fun SettingGroup(title: String, items: List<Pair<String,String>>, nav: NavHostController) {
    Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Sakura, modifier = Modifier.padding(start = 4.dp, top = 10.dp, bottom = 6.dp))
    Card(shape = RoundedCornerShape(20.dp)) { Column { items.forEachIndexed { index, (a,b) ->
        val route = when(a) { "Learning content" -> "settings/learning"; "Flashcards" -> "settings/flashcards"; "Quiz" -> "settings/quiz"; "JLPT level" -> "settings/jlpt"; "Widget appearance" -> "settings/widget"; "Theme" -> "settings/theme"; "Notifications" -> "settings/notifications"; "Backup" -> "settings/backup"; else -> "settings/faq" }
        Row(Modifier.fillMaxWidth().clickable { nav.navigate(route) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(34.dp).clip(CircleShape).background(Sakura.copy(.12f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.ChevronRight, null, tint = Sakura, modifier = Modifier.size(18.dp)) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(a, fontWeight = FontWeight.SemiBold); Text(b, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }; Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (index != items.lastIndex) HorizontalDivider()
    } } }
}

@Composable
private fun ThemePreviewRow(dark: Boolean) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { ThemeMiniCard("Sunset (Dark)", true, Modifier.weight(1f)); ThemeMiniCard("Daylight (Light)", false, Modifier.weight(1f)) } }

@Composable
private fun ThemeMiniCard(title: String, dark: Boolean, modifier: Modifier) { Box(modifier.height(110.dp).clip(RoundedCornerShape(18.dp))) { SakuraScene(dark, Modifier.fillMaxSize()); Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) } } }

@Composable
private fun WidgetAppearance(vm: MainViewModel, nav: NavHostController, dark: Boolean) {
    val context = LocalContext.current; val prefs = remember { context.getSharedPreferences("tyro_settings", 0) }
    var font by remember { mutableStateOf(prefs.getString("widget_font", "sans") ?: "sans") }; var size by remember { mutableIntStateOf(prefs.getInt("widget_size", 48)) }; var color by remember { mutableStateOf(prefs.getString("widget_color", "auto") ?: "auto") }; var refresh by remember { mutableIntStateOf(prefs.getInt("widget_auto_refresh", 5)) }
    val colors = listOf("auto" to "Device", "white" to "White", "black" to "Black", "pink" to "Sakura", "blue" to "Blue", "green" to "Green", "purple" to "Purple", "orange" to "Orange", "red" to "Red", "cyan" to "Cyan", "gold" to "Gold")
    val refreshes = listOf(0 to "Off", 5 to "5m", 10 to "10m", 30 to "30m", 60 to "1h", 120 to "2h", 720 to "12h", 1440 to "1d")
    AppShell("Widget", nav, 3) {
        Text("Changes are pushed to every existing widget immediately.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp)); WidgetPreview(font, size, color, dark)
        Spacer(Modifier.height(16.dp)); Text("Font", fontWeight = FontWeight.Bold); ChipRow(listOf("sans" to "Sans", "serif" to "Serif", "mono" to "Mono", "cursive" to "Cursive"), font) { font = it; vm.saveWidgetFont(it) }
        Spacer(Modifier.height(12.dp)); Text("Kanji size", fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton({ val v=(size-4).coerceAtLeast(28); size=v; vm.saveWidgetSize(v) }) { Icon(Icons.Default.Remove, "Smaller") }; Text("$size sp", fontWeight = FontWeight.Bold, modifier = Modifier.width(70.dp)); IconButton({ val v=(size+4).coerceAtMost(96); size=v; vm.saveWidgetSize(v) }) { Icon(Icons.Default.Add, "Larger") } }
        Text("Color", fontWeight = FontWeight.Bold); ChipRow(colors, color) { color=it; vm.saveWidgetColor(it) }
        Spacer(Modifier.height(12.dp)); Text("Automatic refresh", fontWeight = FontWeight.Bold); ChipRow(refreshes, refresh) { refresh=it; vm.saveWidgetAutoRefresh(it) }
        Spacer(Modifier.height(10.dp)); Text("↻ on the widget changes the Kanji instantly. Color and size controls call the widget update API immediately, so you do not need to remove/re-add the widget.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}

@Composable
private fun <T> ChipRow(items: List<Pair<T,String>>, selected: T, onPick: (T)->Unit) { Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { items.forEach { (key,label) -> FilterChip(selected == key, { onPick(key) }, label = { Text(label) }) } } }

@Composable
private fun WidgetPreview(font: String, size: Int, color: String, dark: Boolean) {
    val fg = when(color) { "white" -> Color.White; "black" -> Color.Black; "pink" -> Sakura; "blue" -> Color(0xFF4D8DFF); "green" -> Color(0xFF4CAF50); "purple" -> Color(0xFF9C6ADE); "orange" -> Color(0xFFFF9800); else -> if(dark) Color.White else Ink }
    Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(24.dp)).background(if(dark) Color(0xFF09090D) else Color(0xFFF2EEF0))) {
        Column(Modifier.fillMaxSize().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text("↻", color=fg, modifier=Modifier.align(Alignment.End)); Text("森", color=fg, fontSize=size.coerceIn(32,72).sp, fontWeight=FontWeight.Bold); Text("もり  •  forest", color=fg, fontSize=13.sp) }
    }
}

@Composable
private fun ThemeSettings(vm: MainViewModel, nav: NavHostController, dark: Boolean) {
    val theme by vm.theme.collectAsState()
    AppShell("Choose Your Theme", nav, 3) {
        Text("Dynamic Japan is the default and adapts automatically.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
        Spacer(Modifier.height(14.dp))
        ThemeChoice("🌿 Dynamic Japan • Time + Season", "japan_dynamic", theme == "japan_dynamic") { vm.setTheme("japan_dynamic") }
        Spacer(Modifier.height(10.dp))
        ThemeChoice("🌸 Cherry Blossom • Day", "light", theme == "light") { vm.setTheme("light") }
        Spacer(Modifier.height(10.dp))
        ThemeChoice("✨ Fireflies • Night", "dark", theme == "dark") { vm.setTheme("dark") }
        Spacer(Modifier.height(10.dp))
        ThemeChoice("❄️ Winter • Mt. Fuji", "winter", theme == "winter") { vm.setTheme("winter") }
        Spacer(Modifier.height(10.dp))
        ThemeChoice("🎆 Fireworks • Festival", "fireworks", theme == "fireworks") { vm.setTheme("fireworks") }
        Spacer(Modifier.height(16.dp))
        Button({ vm.setTheme("system"); nav.popBackStack() }, Modifier.fillMaxWidth(), shape=RoundedCornerShape(18.dp)) { Text("Use Device Theme") }
    }
}


@Composable
private fun ThemeChoice(title: String, theme: String, selected: Boolean, onClick: ()->Unit) {
    Box(
        Modifier.fillMaxWidth().height(128.dp).clip(RoundedCornerShape(20.dp)).clickable(onClick=onClick)
    ) {
        LiveBackground(theme, Modifier.fillMaxSize())
        val tc = themeTextColor(theme)
        Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
            Text(title, color=tc, fontWeight=FontWeight.Bold)
            Text("Live animated Japanese atmosphere", color=tc.copy(.88f), fontSize=12.sp)
        }
        if(selected) Box(
            Modifier.align(Alignment.TopEnd).padding(10.dp).size(28.dp).clip(CircleShape).background(Color.White),
            contentAlignment=Alignment.Center
        ) { Icon(Icons.Default.Check, null, tint=Sakura, modifier=Modifier.size(18.dp)) }
    }
}

@Composable private fun InfoLine(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String) { Row(Modifier.fillMaxWidth().padding(vertical=7.dp), verticalAlignment=Alignment.CenterVertically) { Icon(icon, null, tint=Sakura); Spacer(Modifier.width(12.dp)); Column { Text(title, fontWeight=FontWeight.SemiBold); Text(sub, color=MaterialTheme.colorScheme.onSurfaceVariant, fontSize=12.sp) } } }

@Composable
private fun LearningContent(vm: MainViewModel, nav: NavHostController) {
    val all by vm.kanji.collectAsState(); val selected by vm.selectedIds.collectAsState(); var search by remember { mutableStateOf("") }; var importText by remember { mutableStateOf("") }; var showImport by remember { mutableStateOf(false) }
    val visible = all.filter { search.isBlank() || it.kanji.contains(search) || it.hiragana.contains(search, true) || it.meaning.contains(search, true) }
    AppShell("Learning Content", nav, 3) {
        Row(verticalAlignment=Alignment.CenterVertically) { Text("${selected.size} / ${all.size} selected", fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f)); TextButton({vm.selectAll()}){Text("All")}; TextButton({vm.clearSelection()}){Text("None")} }
        OutlinedTextField(search,{search=it},Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Search Kanji")},leadingIcon={Icon(Icons.Default.Search,null)})
        Spacer(Modifier.height(8.dp)); LazyColumn(contentPadding=PaddingValues(bottom=20.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) { items(visible,key={it.id}) { k -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable{vm.setSelected(k.id,k.id !in selected)}.padding(8.dp),verticalAlignment=Alignment.CenterVertically){ Checkbox(k.id in selected,{vm.setSelected(k.id,it)}); Text(k.kanji,fontSize=28.sp,modifier=Modifier.width(56.dp)); Column{Text(k.hiragana);Text(k.meaning,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)}; if(k.id>=10000) IconButton({vm.deleteImportedKanji(k.id)}){Icon(Icons.Default.Delete,"Delete")} } }; item { OutlinedButton({importText="";showImport=true},Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(7.dp));Text("Import New Kanji")} } }
    }
    if(showImport) AlertDialog(onDismissRequest={showImport=false},title={Text("Import New Kanji")},text={OutlinedTextField(importText,{importText=it},Modifier.fillMaxWidth().height(180.dp),placeholder={Text("海 — うみ — sea")})},confirmButton={Button({vm.importKanji(importText);showImport=false}){Text("Import")}},dismissButton={TextButton({showImport=false}){Text("Cancel")}})
}

@Composable private fun FlashcardSettings(vm: MainViewModel, nav: NavHostController) { val shuffle by vm.shuffle.collectAsState(); AppShell("Flashcards",nav,3){ SettingSwitch("Shuffle Kanji","Show selected Kanji in a different order when you refresh Study.",shuffle,vm::setShuffle); Spacer(Modifier.height(14.dp)); Text("Use the refresh button in Review to instantly start with a new Kanji.",color=MaterialTheme.colorScheme.onSurfaceVariant) } }
@Composable private fun QuizSettings(nav: NavHostController) { AppShell("Quiz",nav,3){Text("Answer layout",fontWeight=FontWeight.Bold,fontSize=18.sp);Text("4 choices in a compact 2 × 2 layout. Wrong answers come from the Kanji catalog.",color=MaterialTheme.colorScheme.onSurfaceVariant)} }
@Composable
private fun JlptSettings(vm: MainViewModel, nav: NavHostController) {
    val level by vm.jlptLevel.collectAsState()
    AppShell("Choose Kanji level", nav, 3) {
        Text("Choose which PDF Kanji set you want to study. This also controls Flashcards, Quiz, SRS, and the Home Screen Widget.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        JlptLevelChoice("N5", "N5 • 120 Kanji", "Study only the 120 N5 Kanji", level == "N5") { vm.setJlptLevel("N5") }
        Spacer(Modifier.height(10.dp))
        JlptLevelChoice("N4", "N4 • 200 Kanji", "Study only the 200 N4 Kanji", level == "N4") { vm.setJlptLevel("N4") }
        Spacer(Modifier.height(10.dp))
        JlptLevelChoice("ALL", "N5 + N4 • 320 Kanji", "Study all 320 Kanji from your PDF", level == "ALL") { vm.setJlptLevel("ALL") }
        Spacer(Modifier.height(14.dp))
        Text("Changing the level resets the widget to the first Kanji in that selected set.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}

@Composable
private fun JlptLevelChoice(value: String, title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = onClick)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
        }
    }
}
@Composable
private fun NotificationSettings(nav: NavHostController) {
    val context = LocalContext.current
    val activity = context as? ComponentActivity
    AppShell("Notifications", nav, 3) {
        Text("Gentle learning reminders every 2 hours.", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "TYRO KANJI will send a sweet reminder about every 2 hours. Android may slightly adjust delivery time for battery protection.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))
        Button({
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                activity?.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9002)
            } else {
                NotificationScheduler.schedule(context)
            }
        }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Text("Enable 2-hour reminders")
        }
        Spacer(Modifier.height(8.dp))
        Text(
            if (android.os.Build.VERSION.SDK_INT >= 33)
                "Tap the button to grant notification permission, then the 2-hour schedule starts."
            else
                "The 2-hour schedule starts immediately.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp
        )
    }
}

@Composable private fun SimpleSettingsPage(title:String,body:String,nav:NavHostController){AppShell(title,nav,3){Text(body,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable private fun SettingSwitch(title:String,subtitle:String,checked:Boolean,onChange:(Boolean)->Unit){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(subtitle,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)};Switch(checked,onChange)}}

@Composable private fun themeDark(): Boolean = androidx.compose.foundation.isSystemInDarkTheme()
