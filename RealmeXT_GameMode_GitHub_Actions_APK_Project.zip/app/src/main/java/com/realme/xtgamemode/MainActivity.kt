package com.realme.xtgamemode
import android.Manifest
import android.app.*
import android.content.*
import android.os.*
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import android.net.ConnectivityManager
import android.view.Gravity

class MainActivity : Activity() {
    private lateinit var status: TextView
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onCreate(b:Bundle?) { super.onCreate(b)
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(dp(16),dp(16),dp(16),dp(16)); root.setBackgroundColor(Color.rgb(11,16,32))
        val title=TextView(this); title.text="🎮  XT GAME MODE"; title.textSize=24f; title.setTextColor(Color.WHITE); root.addView(title)
        val sub=TextView(this); sub.text="Realme XT • 4GB • 60 FPS target"; sub.setTextColor(Color.LTGRAY); root.addView(sub)
        status=TextView(this); status.text="● GAME MODE OFF"; status.textSize=18f; status.setTextColor(Color.LTGRAY); status.gravity=Gravity.CENTER; status.setPadding(0,dp(20),0,dp(20)); root.addView(status)
        val start=Button(this); start.text="START GAME MODE"; root.addView(start)
        val stop=Button(this); stop.text="STOP GAME MODE"; root.addView(stop)
        val launch=Button(this); launch.text="OPEN FREE FIRE"; root.addView(launch)
        val info=TextView(this); info.text="\n60 FPS target • network monitor • temperature monitor • foreground gaming session\n\nThis app does not edit Free Fire files or bypass anti-cheat."; info.setTextColor(Color.LTGRAY); root.addView(info)
        start.setOnClickListener { if(Build.VERSION.SDK_INT>=33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),44); startService(Intent(this,GameModeService::class.java)); status.text="● GAME MODE ACTIVE" }
        stop.setOnClickListener { stopService(Intent(this,GameModeService::class.java)); status.text="● GAME MODE OFF" }
        launch.setOnClickListener { try { startActivity(packageManager.getLaunchIntentForPackage("com.dts.freefireth") ?: packageManager.getLaunchIntentForPackage("com.dts.freefiremax")) } catch(_:Exception){ Toast.makeText(this,"Free Fire not found",Toast.LENGTH_SHORT).show() } }
        setContentView(root)
    }
}