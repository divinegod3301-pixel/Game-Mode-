package com.realme.xtgamemode
import android.app.*
import android.content.*
import android.os.*
import android.net.*
import android.graphics.Color
import kotlin.math.roundToInt

class GameModeService: Service() {
    private val handler=Handler(Looper.getMainLooper())
    private val tick=object:Runnable { override fun run(){ update(); handler.postDelayed(this,3000) } }
    override fun onCreate(){ super.onCreate(); createChannel(); startForeground(7, notification("Game Mode active • 60 FPS target")); handler.post(tick) }
    private fun update(){
        val cm=getSystemService(ConnectivityManager::class.java)
        val n=cm.activeNetwork
        val caps=cm.getNetworkCapabilities(n)
        val net=when { caps==null -> "Offline"; caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)->"Wi‑Fi"; caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)->"Mobile data"; else->"Connected" }
        val temp=try { val t=BatteryManager::class.java; val bm=getSystemService(BATTERY_SERVICE) as BatteryManager; "Battery ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%" } catch(_:Exception){"Battery OK"}
        val nm=getSystemService(NotificationManager::class.java); nm.notify(7,notification("Game Mode active • $net • $temp"))
    }
    private fun notification(text:String):Notification {
        return Notification.Builder(this,"game").setContentTitle("XT Game Mode").setContentText(text).setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
    }
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("game","Game Mode",NotificationManager.IMPORTANCE_LOW)) }
    override fun onDestroy(){ handler.removeCallbacks(tick); super.onDestroy() }
    override fun onBind(i:Intent?)=null
}