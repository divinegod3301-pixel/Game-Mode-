# Realme XT Game Mode

A no-root/no-PC Android project for a Realme XT.

Features:
- One-tap foreground gaming session
- 60 FPS target profile (does not force protected game limits)
- Free Fire launch button
- Network transport monitoring
- Battery status monitoring
- Persistent gaming notification
- Safe stop button
- No game-file modification or anti-cheat bypass

Free Fire package launch tries `com.dts.freefireth` and then `com.dts.freefiremax`.

Build with Android Studio. For Android 14/15/16, foreground-service rules and OEM battery restrictions may require user action.


## Build APK from your phone with GitHub Actions

1. Create a GitHub repository and upload the contents of this project.
2. Keep `.github/workflows/build-apk.yml` in the repository.
3. Open the repository's **Actions** tab.
4. Run **Build XT Game Mode APK** (or push to `main`).
5. Open the completed workflow run and download the `RealmeXT-GameMode-debug` artifact.
6. Extract the APK and install it on the Realme XT.

GitHub documents workflows under `.github/workflows` and workflow artifacts for downloading build outputs.
