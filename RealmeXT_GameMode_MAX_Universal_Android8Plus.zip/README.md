# Realme XT Game Mode MAX — Android 8+

Focus: highest practical sustained smoothness for Free Fire, with a 60-FPS/high-FPS target and network/thermal monitoring.

What it does:
- One-tap MAX gaming session.
- Opens Free Fire.
- Foreground service remains active while the session is running.
- Wi-Fi high-performance lock during the user-initiated session where supported.
- Network transport monitoring.
- Battery percentage and battery temperature monitoring.
- Screen/session wake lock.
- Android 8+ minSdk.
- Android 13+ notification permission handling.
- Android 14+ special-use foreground-service declaration.

What it cannot do without root/system privileges:
- Force Free Fire's internal FPS cap to 60.
- Change Free Fire protected data/OBB/config files.
- Increase ISP/mobile-network speed.
- Disable Android/OEM thermal throttling.

Recommended in-game profile:
Smooth + High/60 FPS; reduce shadows/high-resolution/effects if the phone heats up.

For automatic detection of Free Fire leaving the foreground, the app exposes Android's Usage Access settings. Android/OEM restrictions may require the user to grant this access and battery-optimization exemption.
