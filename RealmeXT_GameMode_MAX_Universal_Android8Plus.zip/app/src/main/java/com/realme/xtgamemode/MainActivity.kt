package com.realme.xtgamemode

import android.Manifest
import android.app.*
import android.content.*
import android.net.wifi.WifiManager
import android.os.*
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun btn(text:String)=Button(this).apply { this.text=text; setTextColor(Color.WHITE) }

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(16),dp(14),dp(16),dp(14))
            setBackgroundColor(Color.rgb(11,16,32))
        }
        val title=TextView(this).apply { text="🎮 XT GAME MODE MAX"; textSize=24f; setTextColor(Color.WHITE) }
        val sub=TextView(this).apply { text="Universal Android 8+ • 60 FPS / High-FPS target"; setTextColor(Color.LTGRAY) }
        root.addView(title); root.addView(sub)

        status=TextView(this).apply {
            text="● READY — MAX SMOOTH PROFILE"
            textSize=18f; setTextColor(Color.rgb(114,230,165)); gravity=Gravity.CENTER
            setPadding(0,dp(18),0,dp(18))
        }
        root.addView(status)

        val start=btn("🚀 START MAX GAME MODE")
        val stop=btn("■ STOP GAME MODE")
        val launch=btn("🎮 START + OPEN FREE FIRE")
        val usage=btn("⚙ AUTO-DETECT SETUP")
        val battery=btn("🔋 BATTERY OPTIMIZATION SETUP")
        root.addView(start); root.addView(launch); root.addView(stop); root.addView(usage); root.addView(battery)

        val info=TextView(this).apply {
            text="\nTARGET PROFILE\n• Free Fire: Smooth + High/60 FPS\n• Effects/shadows: reduce for frame stability\n• Network: active transport monitoring + Wi‑Fi high-performance lock while session runs\n• CPU/GPU: no unsafe governor hacks\n• Thermal: battery/temperature monitoring\n• Auto-detect: Usage Access can detect when Free Fire leaves the foreground\n\n⚠ This app cannot force an internal 60-FPS limit, raise ISP speed, or edit protected Free Fire files. It targets the highest stable performance Android exposes."
            setTextColor(Color.LTGRAY); textSize=13f
        }
        root.addView(info)

        start.setOnClickListener { startMode(false) }
        launch.setOnClickListener { startMode(true) }
        stop.setOnClickListener { stopService(Intent(this,GameModeService::class.java)); status.text="● GAME MODE OFF" }
        usage.setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        battery.setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply { data=android.net.Uri.parse("package:$packageName") }) }
            catch(_:Exception){ startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
        setContentView(root)
    }

    private fun startMode(openGame:Boolean) {
        if (Build.VERSION.SDK_INT>=33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),44)
        val i=Intent(this,GameModeService::class.java)
        if (Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
        status.text="● GAME MODE ACTIVE • 60 FPS TARGET"
        if(openGame) {
            val pm=packageManager
            val intent=pm.getLaunchIntentForPackage("com.dts.freefireth")
                ?: pm.getLaunchIntentForPackage("com.dts.freefiremax")
            if(intent!=null) startActivity(intent)
            else Toast.makeText(this,"Free Fire not found",Toast.LENGTH_SHORT).show()
        }
    }
}
