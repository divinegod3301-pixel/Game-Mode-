package com.realme.xtgamemode

import android.app.*
import android.content.*
import android.net.*
import android.net.wifi.WifiManager
import android.os.*
import java.util.*

class GameModeService: Service() {
    private val handler=Handler(Looper.getMainLooper())
    private var wifiLock: WifiManager.WifiLock?=null
    private var wakeLock: PowerManager.WakeLock?=null
    private val tick=object:Runnable { override fun run(){ update(); handler.postDelayed(this,5000) } }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, notification("MAX mode active • 60 FPS target"))
        acquireLocks()
        handler.post(tick)
    }

    private fun acquireLocks() {
        try {
            val wm=getSystemService(WIFI_SERVICE) as WifiManager
            wifiLock=wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "XTGameMode:WiFi")
            wifiLock?.acquire()
        } catch(_:Exception) {}
        try {
            val pm=getSystemService(POWER_SERVICE) as PowerManager
            wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "XTGameMode:Session")
            wakeLock?.acquire(6*60*60*1000L)
        } catch(_:Exception) {}
    }

    private fun update() {
        val cm=getSystemService(ConnectivityManager::class.java)
        val n=cm.activeNetwork
        val caps=cm.getNetworkCapabilities(n)
        val net=when {
            caps==null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi‑Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
            else -> "Connected"
        }
        val bm=getSystemService(BATTERY_SERVICE) as BatteryManager
        val pct=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val temp=try {
            val f=registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val tenth=f?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            if(tenth>0) String.format(Locale.US, "%.1f°C", tenth/10.0) else "Temp n/a"
        } catch(_:Exception) {"Temp n/a"}
        val nm=getSystemService(NotificationManager::class.java)
        nm.notify(7, notification("MAX active • $net • $pct% • $temp"))
    }

    private fun notification(text:String)=Notification.Builder(this,"game")
        .setContentTitle("XT Game Mode MAX")
        .setContentText(text)
        .setSmallIcon(android.R.drawable.ic_media_play)
        .setOngoing(true).build()

    private fun createChannel() {
        if(Build.VERSION.SDK_INT>=26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel("game","Game Mode",NotificationManager.IMPORTANCE_LOW))
        }
    }
    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { wifiLock?.let { if(it.isHeld) it.release() } } catch(_:Exception){}
        try { wakeLock?.let { if(it.isHeld) it.release() } } catch(_:Exception){}
        super.onDestroy()
    }
    override fun onBind(i:Intent?)=null
}
