package com.tyro.kanji

import android.os.Bundle
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.tyro.kanji.data.KanjiEntity
import kotlin.math.PI
import kotlin.math.sin

private val Sakura = Color(0xFFE56B88)
private val SakuraSoft = Color(0xFFFFB8C7)
private val Ink = Color(0xFF17151B)
private val Night = Color(0xFF111116)
private val NightCard = Color(0xFF1A1920)
private val Cream = Color(0xFFFFF7F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TyroKanjiApp() }
    }
}

@Composable
fun TyroKanjiApp(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val theme by vm.theme.collectAsState()
    val prefs = LocalContext.current.getSharedPreferences("tyro_settings", 0)
    var onboardingDone by remember { mutableStateOf(prefs.getBoolean("onboarding_done", false)) }
    val dark = theme == "dark" || (theme == "system" && androidx.compose.foundation.isSystemInDarkTheme())

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = Sakura, secondary = SakuraSoft, background = Night, surface = NightCard)
        else lightColorScheme(primary = Sakura, secondary = Color(0xFF9E4960), background = Cream, surface = Color.White)
    ) {
        if (!onboardingDone) {
            ThemeOnboarding(dark, vm) {
                prefs.edit().putBoolean("onboarding_done", true).commit()
                onboardingDone = true
            }
        } else {
            Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                NavHost(navController = nav, startDestination = "home", modifier = Modifier.fillMaxSize()) {
                    composable("home") { Home(vm, dark, nav) }
                    composable("learn") { Learn(vm, nav) }
                    composable("study") { Study(vm, nav) }
                    composable("stats") { Stats(vm, nav) }
                    composable("settings") { Settings(nav, vm, dark) }
                    composable("settings/learning") { LearningContent(vm, nav) }
                    composable("settings/flashcards") { FlashcardSettings(vm, nav) }
                    composable("settings/quiz") { QuizSettings(nav) }
                    composable("settings/widget") { WidgetAppearance(vm, nav, dark) }
                    composable("settings/theme") { ThemeSettings(vm, nav, dark) }
                    composable("settings/jlpt") { JlptSettings(vm, nav) }
                    composable("settings/notifications") { SimpleSettingsPage("Notifications", "Notification controls can be enabled here. The current build keeps notifications off by default.", nav) }
                    composable("settings/backup") { SimpleSettingsPage("Backup", "Your learning data is stored locally on the device. Backup/export can be added here without changing your study data.", nav) }
                    composable("settings/faq") { SimpleSettingsPage("FAQ", "Choose your Kanji in Learning content, refresh Study for a new Kanji, and use the widget ↻ button for an instant change.", nav) }
                    composable("detail/{id}") { entry ->
                        val id = entry.arguments?.getString("id")?.toIntOrNull()
                        val k by vm.kanji.collectAsState()
                        k.firstOrNull { it.id == id }?.let { Detail(it, vm, nav) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeOnboarding(initialDark: Boolean, vm: MainViewModel, onBegin: () -> Unit) {
    var selectedDark by remember { mutableStateOf(initialDark) }
    Box(Modifier.fillMaxSize()) {
        SakuraScene(selectedDark, Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(24.dp))
            Text("TYRO KANJI", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Bold)
            Text("TYRO KANJI", color = Color.White.copy(.92f), fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = if (selectedDark) Color(0xFFE9D7DE).copy(.96f) else Color(0xFFFFF8F6).copy(.96f))) {
                Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Choose Your Theme", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("You can change it anytime", color = Ink.copy(.68f), fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    ThemeChoice("Sunset (Dark)", true, selectedDark) { selectedDark = true }
                    Spacer(Modifier.height(10.dp))
                    ThemeChoice("Daylight (Light)", false, !selectedDark) { selectedDark = false }
                    Spacer(Modifier.height(12.dp))
                    InfoLine(Icons.Default.LocalFlorist, "Cherry Blossoms", "Falling petals animation")
                    InfoLine(Icons.Default.AutoAwesome, "Japanese Atmosphere", "Calm & beautiful")
                    InfoLine(Icons.Default.Favorite, "Respect Japanese Culture", "Learn with inspiration")
                    Spacer(Modifier.weight(1f))
                    Button({ vm.setTheme(if (selectedDark) "dark" else "light"); onBegin() }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("Let's Begin  ❀") }
                }
            }
            Spacer(Modifier.height(12.dp)); Text("Learn Kanji. Live Japan.", color = Color.White.copy(.9f), fontSize = 13.sp)
        }
    }
}

@Composable
private fun SakuraScene(dark: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "sakuraPetals")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(9000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        ),
        label = "petalDrift"
    )
    val top = if (dark) Color(0xFF17131F) else Color(0xFFFFEEF5)
    val middle = if (dark) Color(0xFF4A2538) else Color(0xFFFFD5C8)
    val bottom = if (dark) Color(0xFF9A4D50) else Color(0xFFFFB6A4)
    val sun = if (dark) Color(0xFFFFB45C) else Color(0xFFFFD78D)
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(listOf(top, middle, bottom)))
        // Soft sunset glow
        drawCircle(sun.copy(alpha = if (dark) .88f else .78f), size.minDimension * .115f, Offset(size.width * .70f, size.height * .57f))
        drawCircle(Color.White.copy(alpha = if (dark) .05f else .22f), size.minDimension * .19f, Offset(size.width * .70f, size.height * .57f))
        // Distant Fuji-like mountains and nearer hills
        mountain(this, Color(0xFF5C4A60).copy(alpha = if (dark) .90f else .36f), .52f, .38f)
        mountain(this, Color(0xFF332B3D).copy(alpha = if (dark) .94f else .30f), .78f, .48f)
        // Water and reflection
        drawRect(Color(0xFF342D42).copy(alpha = if (dark) .72f else .14f), Offset(0f, size.height*.70f), androidx.compose.ui.geometry.Size(size.width,size.height*.30f))
        for (i in 0 until 10) {
            val y = size.height * (.73f + i * .022f)
            val width = size.width * (.12f + (i % 4) * .05f)
            drawLine(Color(0xFFFFC4B2).copy(alpha = if (dark) .16f else .24f), Offset(size.width*.70f-width, y), Offset(size.width*.70f+width, y), strokeWidth = 2f)
        }
        // Pagoda silhouette
        val px = size.width * .84f; val base = size.height * .72f
        drawRect(Color(0xFF2A222F).copy(alpha=.90f), Offset(px-size.width*.014f, base-size.height*.30f), androidx.compose.ui.geometry.Size(size.width*.028f,size.height*.30f))
        repeat(4) { i ->
            val y = base - i * size.height * .055f
            val w = size.width * (.14f - i * .018f)
            drawRect(Color(0xFF2A222F).copy(alpha=.92f), Offset(px-w/2, y-size.height*.045f), androidx.compose.ui.geometry.Size(w, size.height*.045f))
            val roof = Path().apply { moveTo(px-w*.72f,y-size.height*.045f); lineTo(px,y-size.height*.073f); lineTo(px+w*.72f,y-size.height*.045f); close() }
            drawPath(roof, Color(0xFF1E1924).copy(alpha=.96f))
        }
        // Torii silhouette
        val tx = size.width * .24f; val ty = size.height * .72f
        val torii = Color(0xFF8F3D4C).copy(alpha = if (dark) .85f else .58f)
        drawRect(torii, Offset(tx-size.width*.045f, ty-size.height*.17f), androidx.compose.ui.geometry.Size(size.width*.018f,size.height*.18f))
        drawRect(torii, Offset(tx+size.width*.027f, ty-size.height*.17f), androidx.compose.ui.geometry.Size(size.width*.018f,size.height*.18f))
        drawRect(torii, Offset(tx-size.width*.075f, ty-size.height*.18f), androidx.compose.ui.geometry.Size(size.width*.15f,size.height*.024f))
        // Sakura branch silhouette in the upper-left corner
        val branch = Color(0xFF2A2027).copy(alpha = if (dark) .85f else .55f)
        drawLine(branch, Offset(0f, size.height*.13f), Offset(size.width*.36f, size.height*.02f), strokeWidth = size.minDimension*.025f)
        drawLine(branch, Offset(size.width*.18f, size.height*.08f), Offset(size.width*.30f, size.height*.25f), strokeWidth = size.minDimension*.012f)
        // Gently falling petals
        for (i in 0 until 32) {
            val seedX = ((i * 37) % 101) / 100f
            val seedY = ((i * 61) % 101) / 100f
            val x = (seedX + sin((drift * 2f + i) * 1.7f) * .035f).coerceIn(.02f,.98f) * size.width
            val y = ((seedY + drift * (.32f + (i % 4) * .08f)) % 1f) * size.height
            val r = 2.5f + (i % 3)
            drawCircle(SakuraSoft.copy(alpha = if (dark) .88f else .72f), r, Offset(x,y))
            if (i % 5 == 0) drawCircle(Color.White.copy(alpha=.16f), r*.55f, Offset(x-r*.25f,y-r*.25f))
        }
        // foreground vignette
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = if (dark) .16f else .05f))), Offset.Zero, size)
    }
}

private fun mountain(scope: DrawScope, color: Color, x: Float, peak: Float) {
    val p = Path().apply { moveTo(0f, scope.size.height*.72f); lineTo(scope.size.width*x, scope.size.height*peak); lineTo(scope.size.width, scope.size.height*.72f); close() }
    scope.drawPath(p, color)
}

@Composable
private fun AppShell(title: String, nav: NavHostController, selected: Int, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (title != "Home") IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Back") }
                Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                if (title == "Home") IconButton({ nav.navigate("settings") }) { Icon(Icons.Default.Settings, "Settings") }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .96f)) {
                val items = listOf("Home" to Icons.Default.Home, "Learn" to Icons.Default.MenuBook, "Review" to Icons.Default.Replay, "Settings" to Icons.Default.Settings)
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = selected == i, onClick = {
                        val route = listOf("home", "learn", "study", "settings")[i]
                        nav.navigate(route) { launchSingleTop = true; popUpTo("home") }
                    }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 11.sp) })
                }
            }
        }
    ) { pad -> Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp), content = content) }
}

@Composable
private fun Home(vm: MainViewModel, dark: Boolean, nav: NavHostController) {
    val list by vm.kanji.collectAsState(); val mastered by vm.mastered.collectAsState(); val due by vm.due.collectAsState()
    val progress = if (list.isEmpty()) 0f else (mastered.toFloat() / list.size).coerceIn(0f, 1f)
    AppShell("TYRO KANJI", nav, 0) {
        Spacer(Modifier.height(2.dp))
        HeroCard(dark)
        Spacer(Modifier.height(14.dp))
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(progress)
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("Progress", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Keep going. Every Kanji makes you stronger.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Correct  $mastered", fontWeight = FontWeight.SemiBold)
                        Text("Review   $due", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        val cards = listOf(
            Triple("New Kanji", "${list.count { it.id < 10000 }} / 307", Icons.Default.AddCircle),
            Triple("Quiz", "Test your knowledge", Icons.Default.School),
            Triple("Flash Cards", "Review & Remember", Icons.Default.Style),
            Triple("Review", "Mistakes & Mastery", Icons.Default.Replay),
            Triple("Kanji Details", "Meaning & Words", Icons.Default.Description),
            Triple("Widget", "Home screen study", Icons.Default.Widgets)
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            items(cards.chunked(2)) { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (title, sub, icon) ->
                        ActionCard(title, sub, icon, Modifier.weight(1f), onClick = {
                            when (title) { "Quiz", "Review", "Flash Cards" -> nav.navigate("study"); "Widget" -> nav.navigate("settings/widget"); "Kanji Details" -> list.firstOrNull()?.let { nav.navigate("detail/${it.id}") }; else -> nav.navigate("learn") }
                        })
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            item { Spacer(Modifier.height(4.dp)); FeatureStrip(dark) }
        }
    }
}

@Composable
private fun HeroCard(dark: Boolean) {
    Box(Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(24.dp))) {
        SakuraScene(dark, Modifier.fillMaxSize())
        Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
            Text("TYRO KANJI", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
            Text("Learn Kanji. Live Japan.", color = Color.White.copy(.9f), fontSize = 14.sp)
        }
    }
}

@Composable
private fun ProgressRing(progress: Float) {
    Box(Modifier.size(82.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxSize(), strokeWidth = 8.dp, trackColor = MaterialTheme.colorScheme.surfaceVariant)
        Text("${(progress * 100).toInt()}%", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(13.dp).heightIn(min = 78.dp)) {
            Icon(icon, null, tint = Sakura, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(7.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
private fun FeatureStrip(dark: Boolean) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Widget" to Icons.Default.Widgets, "Offline" to Icons.Default.CloudOff, "Backup" to Icons.Default.CloudUpload, "Dark / Light" to Icons.Default.Brightness6).forEach { (label, icon) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Icon(icon, null, tint = Sakura, modifier = Modifier.size(22.dp)); Spacer(Modifier.height(4.dp)); Text(label, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun Learn(vm: MainViewModel, nav: NavHostController) {
    val list by vm.kanji.collectAsState(); var search by remember { mutableStateOf("") }
    val visible = list.filter { search.isBlank() || it.kanji.contains(search) || it.hiragana.contains(search, true) || it.meaning.contains(search, true) }
    AppShell("Learn", nav, 1) {
        OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search Kanji") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        Spacer(Modifier.height(10.dp))
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(visible, key = { it.id }) { k -> KanjiRow(k) { nav.navigate("detail/${k.id}") } }
        }
    }
}

@Composable
private fun KanjiRow(k: KanjiEntity, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Text(k.kanji, fontSize = 30.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(k.hiragana, fontWeight = FontWeight.SemiBold); Text(k.meaning, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) }
            Icon(Icons.Default.ChevronRight, null, tint = Sakura)
        }
    }
}

@Composable
private fun Detail(k: KanjiEntity, vm: MainViewModel, nav: NavHostController) {
    val progress by vm.progress(k.id).collectAsState(initial = null)
    var srsMessage by remember { mutableStateOf("") }
    val context = LocalContext.current
    lateinit var detailTts: TextToSpeech
    detailTts = remember { TextToSpeech(context) { status ->
        if (status == TextToSpeech.SUCCESS) detailTts.language = Locale.JAPANESE
    } }
    DisposableEffect(Unit) { onDispose { detailTts.stop(); detailTts.shutdown() } }
    val examples = remember(k.example) { k.example.split("|").filter { it.isNotBlank() } }
    val exampleReadings = remember(k.exampleRomaji) { k.exampleRomaji.split("|").filter { it.isNotBlank() } }
    val exampleMeanings = remember(k.exampleMeaning) { k.exampleMeaning.split("|").filter { it.isNotBlank() } }

    AppShell("Kanji Details", nav, 1) {
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth().height(230.dp), shape = RoundedCornerShape(28.dp)) {
            Box(Modifier.fillMaxSize()) {
                SakuraScene(themeDark(), Modifier.fillMaxSize())
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(k.kanji, fontSize = 86.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(k.meaning, fontSize = 20.sp, color = Color.White)
                    Text("${k.hiragana}  •  ${k.romaji}", color = Color.White.copy(.88f))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Common use", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Meaning: ${k.meaning}")
                Text("Reading: ${k.hiragana}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Button({
                    val text = if (k.hiragana.isNotBlank() && k.hiragana != "—") k.hiragana else k.kanji
                    detailTts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kanji_${k.id}")
                }) {
                    Icon(Icons.Default.VolumeUp, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Play sound")
                }
                Spacer(Modifier.height(8.dp))
                Text("Mastery ${progress?.mastery ?: 0}/5", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Button({ vm.favorite(k.id, !(progress?.favorite ?: false)) }) {
                    Icon(Icons.Default.Favorite, null); Spacer(Modifier.width(6.dp)); Text(if (progress?.favorite == true) "Saved" else "Favorite")
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
            Card(Modifier.weight(1f), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Readings", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("On'yomi", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(if (k.onyomi.isBlank()) "—" else k.onyomi, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Kun'yomi", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(if (k.kunyomi.isBlank()) "—" else k.kunyomi, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
            }
            Card(Modifier.weight(1f), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Common uses", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (examples.isEmpty()) {
                        Text("No common-use words available yet.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    } else {
                        examples.take(2).forEachIndexed { i, word ->
                            Text(word, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            if (i < exampleReadings.size) Text(exampleReadings[i], color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                            if (i < exampleMeanings.size) Text(exampleMeanings[i], color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                            if (i < minOf(2, examples.size) - 1) Spacer(Modifier.height(9.dp))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp)); Text("SRS review", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Again" to 0, "Hard" to 1, "Good" to 2, "Easy" to 3).forEach { (t, r) ->
                Button({ vm.review(k.id, r); srsMessage = "Saved: $t • next review updated" }, Modifier.weight(1f)) { Text(t, fontSize = 12.sp) }
            }
        }
        if (srsMessage.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(srsMessage, color = Sakura, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun Study(vm: MainViewModel, nav: NavHostController) {
    val all by vm.kanji.collectAsState(); val selected by vm.selectedIds.collectAsState(); val shuffle by vm.shuffle.collectAsState(); val token by vm.refreshToken.collectAsState()
    val list = remember(all, selected, shuffle, token) { vm.studyOrder(all) }
    var index by remember { mutableIntStateOf(0) }; var mode by remember { mutableIntStateOf(0) }; var reveal by remember { mutableStateOf(false) }
    var quizWrong by remember { mutableStateOf(false) }
    LaunchedEffect(list.size) { if (list.isNotEmpty()) index %= list.size }
    val k = list.getOrNull(index)
    fun nextStudy() {
        if (list.isNotEmpty()) index = (index + 1) % list.size
        reveal = false
        quizWrong = false
    }
    AppShell("Review", nav, 2) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(mode == 0, { mode = 0; quizWrong = false }, label = { Text("Flash Cards") }); Spacer(Modifier.width(8.dp)); FilterChip(mode == 1, { mode = 1; quizWrong = false }, label = { Text("Quiz") }); Spacer(Modifier.weight(1f)); Text("${if (list.isEmpty()) 0 else index + 1} / ${list.size}", color = MaterialTheme.colorScheme.onSurfaceVariant); IconButton({ vm.refreshStudy(); index = 0; reveal = false; quizWrong = false }) { Icon(Icons.Default.Refresh, "New Kanji") }
        }
        Spacer(Modifier.height(12.dp))
        if (k == null) EmptyStudy() else if (mode == 0) FlashCard(k, reveal) { reveal = !reveal } else QuizCard(
            k, all,
            onCorrect = { vm.review(k.id, 2); nextStudy() },
            onWrong = { vm.review(k.id, 0); quizWrong = true }
        )
        Spacer(Modifier.height(12.dp))
        if (list.isNotEmpty() && (mode == 0 || quizWrong)) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (mode == 0) OutlinedButton({ index = (index - 1 + list.size) % list.size; reveal = false }, Modifier.weight(1f)) { Text("Previous") }
            Button({ nextStudy() }, Modifier.weight(1f)) { Text("Next  →") }
        }
    }
}

@Composable
private fun EmptyStudy() { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(24.dp)) { Text("No Kanji selected", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("Open Settings → Learning content and choose the Kanji you want to learn.", color = MaterialTheme.colorScheme.onSurfaceVariant) } } }

@Composable
private fun FlashCard(k: KanjiEntity, reveal: Boolean, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().height(410.dp).clickable(onClick = onClick), shape = RoundedCornerShape(28.dp)) {
        Box(Modifier.fillMaxSize()) {
            SakuraScene(themeDark(), Modifier.fillMaxSize())
            Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Tap to ${if (reveal) "hide" else "reveal"}", color = Color.White.copy(.8f), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp)); Text(k.kanji, fontSize = 92.sp, fontWeight = FontWeight.Bold, color = Color.White)
                if (reveal) { Text(k.meaning, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White); Text(k.hiragana, color = Color.White.copy(.9f)); Text(k.romaji, color = Color.White.copy(.72f)) }
            }
        }
    }
}

@Composable
private fun QuizCard(k: KanjiEntity, all: List<KanjiEntity>, onCorrect: () -> Unit, onWrong: () -> Unit) {
    var answered by remember(k.id) { mutableStateOf(false) }
    var selectedId by remember(k.id) { mutableIntStateOf(-1) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    lateinit var quizTts: TextToSpeech
    quizTts = remember(k.id) { TextToSpeech(context) { status ->
        if (status == TextToSpeech.SUCCESS) quizTts.language = Locale.JAPANESE
    } }
    DisposableEffect(k.id) { onDispose { quizTts.stop(); quizTts.shutdown() } }
    val opts = remember(k.id, all) { (listOf(k) + all.filter { it.id != k.id }.shuffled().take(3)).shuffled() }
    val isCorrect = selectedId == k.id
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("What is the meaning of this Kanji?", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(k.kanji, fontSize = 84.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(10.dp))
            IconButton({
                val text = if (k.hiragana.isNotBlank() && k.hiragana != "—") k.hiragana else k.kanji
                quizTts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "quiz_${k.id}")
            }, Modifier.align(Alignment.CenterHorizontally)) { Icon(Icons.Default.VolumeUp, "Play pronunciation") }
            Spacer(Modifier.height(4.dp))
            opts.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { o ->
                        val selected = selectedId == o.id
                        val correctShownAfterWrong = answered && !isCorrect && o.id == k.id
                        val stroke = when {
                            selected && answered && o.id == k.id -> Color(0xFF43A047)
                            selected && answered && o.id != k.id -> Color(0xFFE53935)
                            correctShownAfterWrong -> Color(0xFF43A047)
                            else -> MaterialTheme.colorScheme.outline
                        }
                        val fill = when {
                            selected && answered && o.id == k.id -> Color(0xFF43A047).copy(alpha = .25f)
                            selected && answered && o.id != k.id -> Color(0xFFE53935).copy(alpha = .25f)
                            correctShownAfterWrong -> Color(0xFF43A047).copy(alpha = .10f)
                            else -> Color.Transparent
                        }
                        Box(
                            Modifier.weight(1f).height(58.dp)
                                .border(1.5.dp, stroke, RoundedCornerShape(14.dp))
                                .background(fill, RoundedCornerShape(14.dp))
                                .clickable(enabled = !answered) {
                                    selectedId = o.id
                                    answered = true
                                    if (o.id == k.id) {
                                        scope.launch { delay(350); onCorrect() }
                                    } else {
                                        onWrong()
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(o.meaning, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
            }
            if (answered) {
                Text(if (isCorrect) "Correct! 🎉" else "Wrong!  Correct answer is highlighted in green.", color = if (isCorrect) Color(0xFF43A047) else Color(0xFFE53935), fontWeight = FontWeight.Bold)
                if (isCorrect) Text("Moving to next…", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                else Text("Tap Next to continue.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Stats(vm: MainViewModel, nav: NavHostController) {
    val total by vm.kanji.collectAsState(); val mastered by vm.mastered.collectAsState(); val due by vm.due.collectAsState(); val p = if (total.isEmpty()) 0f else mastered.toFloat()/total.size
    AppShell("Statistics", nav, 3) {
        Spacer(Modifier.height(8.dp)); Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(20.dp)) { Text("Your progress", fontSize = 24.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(16.dp)); ProgressRing(p); Spacer(Modifier.height(12.dp)); Text("$mastered mastered", fontWeight = FontWeight.Bold); Text("$due reviews due", color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(12.dp)); LinearProgressIndicator({ p }, Modifier.fillMaxWidth()) } }
        Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatTile("Total", total.size.toString(), Modifier.weight(1f)); StatTile("Mastered", mastered.toString(), Modifier.weight(1f)); StatTile("Due", due.toString(), Modifier.weight(1f)) }
    }
}

@Composable private fun StatTile(a: String, b: String, modifier: Modifier) { Card(modifier, shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(14.dp)) { Text(b, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text(a, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) } } }

@Composable
private fun Settings(nav: NavHostController, vm: MainViewModel, dark: Boolean) {
    AppShell("Settings", nav, 3) {
        Spacer(Modifier.height(4.dp)); Text("Personalize your Japanese study", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        SettingGroup("Learning", listOf("Learning content" to "Choose exactly which Kanji you learn", "Flashcards" to "Shuffle and study order", "Quiz" to "Question style", "JLPT level" to "JLPT availability"), nav)
        SettingGroup("Appearance", listOf("Widget appearance" to "Font, size, color & instant refresh", "Theme" to "Dark / Light themes"), nav)
        SettingGroup("Other", listOf("Notifications" to "Reminder controls", "Backup" to "Protect your progress", "FAQ" to "Help and tips"), nav)
        Spacer(Modifier.height(12.dp)); ThemePreviewRow(dark)
    }
}

@Composable
private fun SettingGroup(title: String, items: List<Pair<String,String>>, nav: NavHostController) {
    Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Sakura, modifier = Modifier.padding(start = 4.dp, top = 10.dp, bottom = 6.dp))
    Card(shape = RoundedCornerShape(20.dp)) { Column { items.forEachIndexed { index, (a,b) ->
        val route = when(a) { "Learning content" -> "settings/learning"; "Flashcards" -> "settings/flashcards"; "Quiz" -> "settings/quiz"; "JLPT level" -> "settings/jlpt"; "Widget appearance" -> "settings/widget"; "Theme" -> "settings/theme"; "Notifications" -> "settings/notifications"; "Backup" -> "settings/backup"; else -> "settings/faq" }
        Row(Modifier.fillMaxWidth().clickable { nav.navigate(route) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(34.dp).clip(CircleShape).background(Sakura.copy(.12f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.ChevronRight, null, tint = Sakura, modifier = Modifier.size(18.dp)) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(a, fontWeight = FontWeight.SemiBold); Text(b, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }; Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (index != items.lastIndex) HorizontalDivider()
    } } }
}

@Composable
private fun ThemePreviewRow(dark: Boolean) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { ThemeMiniCard("Sunset (Dark)", true, Modifier.weight(1f)); ThemeMiniCard("Daylight (Light)", false, Modifier.weight(1f)) } }

@Composable
private fun ThemeMiniCard(title: String, dark: Boolean, modifier: Modifier) { Box(modifier.height(110.dp).clip(RoundedCornerShape(18.dp))) { SakuraScene(dark, Modifier.fillMaxSize()); Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) } } }

@Composable
private fun WidgetAppearance(vm: MainViewModel, nav: NavHostController, dark: Boolean) {
    val context = LocalContext.current; val prefs = remember { context.getSharedPreferences("tyro_settings", 0) }
    var font by remember { mutableStateOf(prefs.getString("widget_font", "sans") ?: "sans") }; var size by remember { mutableIntStateOf(prefs.getInt("widget_size", 48)) }; var color by remember { mutableStateOf(prefs.getString("widget_color", "auto") ?: "auto") }; var refresh by remember { mutableIntStateOf(prefs.getInt("widget_auto_refresh", 5)) }
    val colors = listOf("auto" to "Device", "white" to "White", "black" to "Black", "pink" to "Sakura", "blue" to "Blue", "green" to "Green", "purple" to "Purple", "orange" to "Orange", "red" to "Red", "cyan" to "Cyan", "gold" to "Gold")
    val refreshes = listOf(0 to "Off", 5 to "5m", 10 to "10m", 30 to "30m", 60 to "1h", 120 to "2h", 720 to "12h", 1440 to "1d")
    AppShell("Widget", nav, 3) {
        Text("Changes are pushed to every existing widget immediately.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp)); WidgetPreview(font, size, color, dark)
        Spacer(Modifier.height(16.dp)); Text("Font", fontWeight = FontWeight.Bold); ChipRow(listOf("sans" to "Sans", "serif" to "Serif", "mono" to "Mono", "cursive" to "Cursive"), font) { font = it; vm.saveWidgetFont(it) }
        Spacer(Modifier.height(12.dp)); Text("Kanji size", fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton({ val v=(size-4).coerceAtLeast(28); size=v; vm.saveWidgetSize(v) }) { Icon(Icons.Default.Remove, "Smaller") }; Text("$size sp", fontWeight = FontWeight.Bold, modifier = Modifier.width(70.dp)); IconButton({ val v=(size+4).coerceAtMost(96); size=v; vm.saveWidgetSize(v) }) { Icon(Icons.Default.Add, "Larger") } }
        Text("Color", fontWeight = FontWeight.Bold); ChipRow(colors, color) { color=it; vm.saveWidgetColor(it) }
        Spacer(Modifier.height(12.dp)); Text("Automatic refresh", fontWeight = FontWeight.Bold); ChipRow(refreshes, refresh) { refresh=it; vm.saveWidgetAutoRefresh(it) }
        Spacer(Modifier.height(10.dp)); Text("↻ on the widget changes the Kanji instantly. Color and size controls call the widget update API immediately, so you do not need to remove/re-add the widget.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}

@Composable
private fun <T> ChipRow(items: List<Pair<T,String>>, selected: T, onPick: (T)->Unit) { Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { items.forEach { (key,label) -> FilterChip(selected == key, { onPick(key) }, label = { Text(label) }) } } }

@Composable
private fun WidgetPreview(font: String, size: Int, color: String, dark: Boolean) {
    val fg = when(color) { "white" -> Color.White; "black" -> Color.Black; "pink" -> Sakura; "blue" -> Color(0xFF4D8DFF); "green" -> Color(0xFF4CAF50); "purple" -> Color(0xFF9C6ADE); "orange" -> Color(0xFFFF9800); else -> if(dark) Color.White else Ink }
    Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(24.dp)).background(if(dark) Color(0xFF09090D) else Color(0xFFF2EEF0))) {
        Column(Modifier.fillMaxSize().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Text("↻", color=fg, modifier=Modifier.align(Alignment.End)); Text("森", color=fg, fontSize=size.coerceIn(32,72).sp, fontWeight=FontWeight.Bold); Text("もり  •  forest", color=fg, fontSize=13.sp) }
    }
}

@Composable
private fun ThemeSettings(vm: MainViewModel, nav: NavHostController, dark: Boolean) {
    val theme by vm.theme.collectAsState()
    AppShell("Choose Your Theme", nav, 3) {
        Text("You can change it anytime", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
        Spacer(Modifier.height(14.dp)); ThemeChoice("Sunset (Dark)", true, theme == "dark") { vm.setTheme("dark") }; Spacer(Modifier.height(10.dp)); ThemeChoice("Daylight (Light)", false, theme == "light") { vm.setTheme("light") }
        Spacer(Modifier.height(18.dp)); InfoLine(Icons.Default.LocalFlorist, "Cherry Blossoms", "Falling petals animation"); InfoLine(Icons.Default.AutoAwesome, "Japanese Atmosphere", "Calm & beautiful"); InfoLine(Icons.Default.Favorite, "Respect Japanese Culture", "Learn with inspiration")
        Spacer(Modifier.height(18.dp)); Button({ vm.setTheme("system"); nav.popBackStack() }, Modifier.fillMaxWidth(), shape=RoundedCornerShape(18.dp)) { Text(if(theme=="system") "Using Device Theme" else "Use Device Theme") }
    }
}

@Composable
private fun ThemeChoice(title: String, dark: Boolean, selected: Boolean, onClick: ()->Unit) { Box(Modifier.fillMaxWidth().height(128.dp).clip(RoundedCornerShape(20.dp)).clickable(onClick=onClick)) { SakuraScene(dark, Modifier.fillMaxSize()); Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) { Text(title, color=Color.White, fontWeight=FontWeight.Bold); Text(if(dark) "Warm sunset & night" else "Soft daylight", color=Color.White.copy(.85f), fontSize=12.sp) }; if(selected) Box(Modifier.align(Alignment.TopEnd).padding(10.dp).size(28.dp).clip(CircleShape).background(Color.White), contentAlignment=Alignment.Center) { Icon(Icons.Default.Check, null, tint=Sakura, modifier=Modifier.size(18.dp)) } } }

@Composable private fun InfoLine(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String) { Row(Modifier.fillMaxWidth().padding(vertical=7.dp), verticalAlignment=Alignment.CenterVertically) { Icon(icon, null, tint=Sakura); Spacer(Modifier.width(12.dp)); Column { Text(title, fontWeight=FontWeight.SemiBold); Text(sub, color=MaterialTheme.colorScheme.onSurfaceVariant, fontSize=12.sp) } } }

@Composable
private fun LearningContent(vm: MainViewModel, nav: NavHostController) {
    val all by vm.kanji.collectAsState(); val selected by vm.selectedIds.collectAsState(); var search by remember { mutableStateOf("") }; var importText by remember { mutableStateOf("") }; var showImport by remember { mutableStateOf(false) }
    val visible = all.filter { search.isBlank() || it.kanji.contains(search) || it.hiragana.contains(search, true) || it.meaning.contains(search, true) }
    AppShell("Learning Content", nav, 3) {
        Row(verticalAlignment=Alignment.CenterVertically) { Text("${selected.size} / ${all.size} selected", fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f)); TextButton({vm.selectAll()}){Text("All")}; TextButton({vm.clearSelection()}){Text("None")} }
        OutlinedTextField(search,{search=it},Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Search Kanji")},leadingIcon={Icon(Icons.Default.Search,null)})
        Spacer(Modifier.height(8.dp)); LazyColumn(contentPadding=PaddingValues(bottom=20.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) { items(visible,key={it.id}) { k -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable{vm.setSelected(k.id,k.id !in selected)}.padding(8.dp),verticalAlignment=Alignment.CenterVertically){ Checkbox(k.id in selected,{vm.setSelected(k.id,it)}); Text(k.kanji,fontSize=28.sp,modifier=Modifier.width(56.dp)); Column{Text(k.hiragana);Text(k.meaning,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)}; if(k.id>=10000) IconButton({vm.deleteImportedKanji(k.id)}){Icon(Icons.Default.Delete,"Delete")} } }; item { OutlinedButton({importText="";showImport=true},Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(7.dp));Text("Import New Kanji")} } }
    }
    if(showImport) AlertDialog(onDismissRequest={showImport=false},title={Text("Import New Kanji")},text={OutlinedTextField(importText,{importText=it},Modifier.fillMaxWidth().height(180.dp),placeholder={Text("海 — うみ — sea")})},confirmButton={Button({vm.importKanji(importText);showImport=false}){Text("Import")}},dismissButton={TextButton({showImport=false}){Text("Cancel")}})
}

@Composable private fun FlashcardSettings(vm: MainViewModel, nav: NavHostController) { val shuffle by vm.shuffle.collectAsState(); AppShell("Flashcards",nav,3){ SettingSwitch("Shuffle Kanji","Show selected Kanji in a different order when you refresh Study.",shuffle,vm::setShuffle); Spacer(Modifier.height(14.dp)); Text("Use the refresh button in Review to instantly start with a new Kanji.",color=MaterialTheme.colorScheme.onSurfaceVariant) } }
@Composable private fun QuizSettings(nav: NavHostController) { AppShell("Quiz",nav,3){Text("Answer layout",fontWeight=FontWeight.Bold,fontSize=18.sp);Text("4 choices in a compact 2 × 2 layout. Wrong answers come from the Kanji catalog.",color=MaterialTheme.colorScheme.onSurfaceVariant)} }
@Composable
private fun JlptSettings(vm: MainViewModel, nav: NavHostController) {
    val level by vm.jlptLevel.collectAsState()
    AppShell("Choose Kanji level", nav, 3) {
        Text("Choose which PDF Kanji set you want to study. This also controls Flashcards, Quiz, SRS, and the Home Screen Widget.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        JlptLevelChoice("N5", "N5 • 120 Kanji", "Study only the 120 N5 Kanji", level == "N5") { vm.setJlptLevel("N5") }
        Spacer(Modifier.height(10.dp))
        JlptLevelChoice("N4", "N4 • 200 Kanji", "Study only the 200 N4 Kanji", level == "N4") { vm.setJlptLevel("N4") }
        Spacer(Modifier.height(10.dp))
        JlptLevelChoice("ALL", "N5 + N4 • 320 Kanji", "Study all 320 Kanji from your PDF", level == "ALL") { vm.setJlptLevel("ALL") }
        Spacer(Modifier.height(14.dp))
        Text("Changing the level resets the widget to the first Kanji in that selected set.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}

@Composable
private fun JlptLevelChoice(value: String, title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = onClick)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
        }
    }
}
@Composable private fun SimpleSettingsPage(title:String,body:String,nav:NavHostController){AppShell(title,nav,3){Text(body,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable private fun SettingSwitch(title:String,subtitle:String,checked:Boolean,onChange:(Boolean)->Unit){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(subtitle,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)};Switch(checked,onChange)}}

@Composable private fun themeDark(): Boolean = androidx.compose.foundation.isSystemInDarkTheme()
