package com.realme.xtgamemode

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("mode", MODE_PRIVATE) }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun toggle(label:String,key:String,default:Boolean)=Switch(this).apply {
        text=label; textSize=15f; setTextColor(Color.WHITE); isChecked=prefs.getBoolean(key,default)
        setPadding(0,dp(7),0,dp(7))
        setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean(key,v).apply() }
    }
    private fun button(label:String)=Button(this).apply{text=label}

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        val scroll=ScrollView(this)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(12),dp(15),dp(15));setBackgroundColor(Color.rgb(11,16,32))}
        box.addView(TextView(this).apply{text="🎮 XT GAME MODE MAX";textSize=24f;setTextColor(Color.WHITE)})
        box.addView(TextView(this).apply{text="Realme XT • 4GB • Android 8+";setTextColor(Color.LTGRAY)})
        status=TextView(this).apply{text="● GAME MODE OFF";textSize=18f;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY);setPadding(0,dp(15),0,dp(15))};box.addView(status)
        box.addView(toggle("🎯 60 FPS / High-FPS target","fps",true))
        box.addView(toggle("📶 Network stability monitor","net",true))
        box.addView(toggle("📡 Wi‑Fi high-performance mode","wifi",true))
        box.addView(toggle("🌡️ Thermal / heat monitor","thermal",true))
        box.addView(toggle("🤖 Auto Game Mode for Free Fire","auto",false))
        box.addView(toggle("🔒 Keep gaming session awake","wake",true))
        val on=button("🚀 TURN ON GAME MODE")
        val open=button("🎮 TURN ON + OPEN FREE FIRE")
        val off=button("■ TURN OFF GAME MODE")
        val usage=button("⚙ ENABLE AUTO-DETECT")
        val battery=button("🔋 BATTERY OPTIMIZATION SETTINGS")
        box.addView(on);box.addView(open);box.addView(off);box.addView(usage);box.addView(battery)
        box.addView(TextView(this).apply{text="\nBEST FREE FIRE PROFILE\nSmooth + High/60 FPS • Shadows OFF • High Resolution OFF • Auto Scale OFF\n\nThe MAX mode focuses on sustained frame stability. It cannot force an internal 60-FPS cap, bypass thermal throttling, edit protected Free Fire files, or increase your ISP speed. Close-range stutter can still happen when GPU/CPU load, heat, memory pressure or network jitter rises.";setTextColor(Color.LTGRAY);textSize=13f})
        scroll.addView(box);setContentView(scroll)
        on.setOnClickListener{startMode(false)}
        open.setOnClickListener{startMode(true)}
        off.setOnClickListener{stopService(Intent(this,GameModeService::class.java));status.text="● GAME MODE OFF"}
        usage.setOnClickListener{startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))}
        battery.setOnClickListener{try{startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply{data=Uri.parse("package:$packageName")})}catch(_:Exception){startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))}}
    }
    private fun startMode(openGame:Boolean){
        if(Build.VERSION.SDK_INT>=33)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),44)
        val i=Intent(this,GameModeService::class.java)
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i) else startService(i)
        status.text="● GAME MODE ACTIVE • 60 FPS TARGET"
        if(openGame){val i2=packageManager.getLaunchIntentForPackage("com.dts.freefireth")?:packageManager.getLaunchIntentForPackage("com.dts.freefiremax");if(i2!=null)startActivity(i2)else Toast.makeText(this,"Free Fire not found",Toast.LENGTH_SHORT).show()}
    }
}
