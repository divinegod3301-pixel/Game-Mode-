package com.realme.xtgamemode

import android.app.*
import android.app.usage.UsageStatsManager
import android.content.*
import android.net.*
import android.net.wifi.WifiManager
import android.os.*
import java.util.Locale

class GameModeService: Service(){
    private val h=Handler(Looper.getMainLooper())
    private val prefs by lazy{getSharedPreferences("mode",MODE_PRIVATE)}
    private var wifiLock:WifiManager.WifiLock?=null
    private var wake:PowerManager.WakeLock?=null
    private var autoStarted=false
    private val tick=object:Runnable{override fun run(){monitor();h.postDelayed(this,2500)}}
    override fun onCreate(){super.onCreate();channel();startForeground(7,note("MAX active • 60 FPS target"));locks();h.post(tick)}
    private fun locks(){
        if(prefs.getBoolean("wifi",true))try{val wm=getSystemService(WIFI_SERVICE) as WifiManager;wifiLock=wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF,"XTGameMode:WiFi");wifiLock?.acquire()}catch(_:Exception){}
        if(prefs.getBoolean("wake",true))try{val pm=getSystemService(POWER_SERVICE) as PowerManager;wake=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"XTGameMode:Session");wake?.acquire(6*60*60*1000L)}catch(_:Exception){}
    }
    private fun monitor(){
        val cm=getSystemService(ConnectivityManager::class.java);val caps=cm.getNetworkCapabilities(cm.activeNetwork)
        val net=when{caps==null->"Offline";caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)->"Wi‑Fi";caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)->"Mobile";else->"Connected"}
        val bm=getSystemService(BATTERY_SERVICE) as BatteryManager;val pct=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val temp=try{val x=registerReceiver(null,IntentFilter(Intent.ACTION_BATTERY_CHANGED));(x?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1)?:-1)/10.0}catch(_:Exception){-1.0}
        if(prefs.getBoolean("thermal",true)&&temp>=43.0)getSystemService(NotificationManager::class.java).notify(8,note("🔥 ${String.format(Locale.US,"%.1f",temp)}°C • cool phone to prevent thermal FPS drops"))
        if(prefs.getBoolean("auto",false)){val ff=freeFireForeground();if(!ff&&autoStarted){stopSelf();return};if(ff)autoStarted=true}
        getSystemService(NotificationManager::class.java).notify(7,note("MAX active • $net • $pct% • ${if(temp>=0)String.format(Locale.US,"%.1f°C",temp)else"Temp n/a"}"))
    }
    private fun freeFireForeground():Boolean=try{val u=getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager;val n=System.currentTimeMillis();val s=u.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,n-8000,n);val p=s.maxByOrNull{it.lastTimeUsed}?.packageName;p=="com.dts.freefireth"||p=="com.dts.freefiremax"}catch(_:Exception){true}
    private fun note(t:String)=Notification.Builder(this,"game").setContentTitle("XT Game Mode MAX").setContentText(t).setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
    private fun channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("game","Game Mode",NotificationManager.IMPORTANCE_LOW))}
    override fun onDestroy(){h.removeCallbacks(tick);try{wifiLock?.let{if(it.isHeld)it.release()}}catch(_:Exception){};try{wake?.let{if(it.isHeld)it.release()}}catch(_:Exception){};super.onDestroy()}
    override fun onBind(i:Intent?)=null
}
