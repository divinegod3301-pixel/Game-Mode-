package com.tyro.kanji

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.TaskStackBuilder
import kotlin.random.Random

object NotificationScheduler {
    private const val CHANNEL = "tyro_learning"
    private const val ACTION = "com.tyro.kanji.TWO_HOUR_REMINDER"
    private const val REQUEST = 9101
    private const val INTERVAL = 2L * 60L * 60L * 1000L

    fun schedule(context: Context) {
        createChannel(context)
        val app = context.applicationContext
        val alarm = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(app)
        alarm.cancel(pi)
        alarm.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + INTERVAL,
            pi
        )
    }

    fun cancel(context: Context) {
        val app = context.applicationContext
        val alarm = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pendingIntent(app))
    }

    private fun pendingIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context,
            REQUEST,
            Intent(context, LearningNotificationReceiver::class.java).setAction(ACTION),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL,
                    "TYRO KANJI learning",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply { description = "Gentle TYRO KANJI learning reminders every two hours" }
            )
        }
    }

    internal fun showNotification(context: Context) {
        createChannel(context)
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) return

        val messages = listOf(
            "A tiny Kanji break? 🌸",
            "Ready for one more Kanji? ✨",
            "Your Japanese journey is waiting 📚",
            "A gentle two-hour Kanji moment? 🌸",
            "おつかれさま！ One small review is enough."
        )
        val openApp = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentIntent = TaskStackBuilder.create(context)
            .addNextIntentWithParentStack(openApp)
            .getPendingIntent(
                9100,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(com.tyro.kanji.R.drawable.tyro_icon)
            .setContentTitle("TYRO KANJI")
            .setContentText(messages[Random.nextInt(messages.size)])
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(3200 + Random.nextInt(100), notification)
    }
}

class LearningNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != "com.tyro.kanji.TWO_HOUR_REMINDER") return
        val app = context.applicationContext
        NotificationScheduler.showNotification(app)
        // Chain the next reminder so the schedule survives the app being closed.
        NotificationScheduler.schedule(app)
    }
}
